var searchData=
[
  ['currentsound',['currentSound',['../interface_k_i_t_profile.html#a4b0f589e42f43d1b4a527958479091c0',1,'KITProfile']]]
];
