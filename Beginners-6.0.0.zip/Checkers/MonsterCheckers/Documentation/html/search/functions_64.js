var searchData=
[
  ['defaultattributeforkey_3a',['defaultAttributeForKey:',['../interface_k_i_t_profile.html#a0ce86c68e5b73c53fbeaa31e16466254',1,'KITProfile']]],
  ['directionfromxy_3ato_3a',['directionFromXY:to:',['../interface_checker_board.html#ab060ac0f06989a8ac2353849ec6d268f',1,'CheckerBoard']]]
];
