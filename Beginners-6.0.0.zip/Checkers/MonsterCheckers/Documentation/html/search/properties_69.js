var searchData=
[
  ['isdead',['isDead',['../interface_checker_piece.html#a5b9a6ab27192e6bdf8159cbf9b0a1b60',1,'CheckerPiece']]],
  ['isdying',['isDying',['../interface_checker_piece.html#adeb130eec474b1b3aac30017d7477b2e',1,'CheckerPiece']]],
  ['isking',['isKing',['../interface_checker_piece.html#a33d9bbca9b98908f0363cf83064f5852',1,'CheckerPiece']]]
];
