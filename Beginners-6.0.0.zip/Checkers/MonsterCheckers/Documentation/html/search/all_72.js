var searchData=
[
  ['randomobject',['randomObject',['../interface_n_s_array.html#aee3b777e0c8e36c7c4388e6edaa0e9fd',1,'NSArray']]],
  ['recenter',['recenter',['../interface_u_i_view.html#abaa3ef5316177e5cfb2174aa92e5fc15',1,'UIView']]],
  ['removeallmovepoints',['removeAllMovePoints',['../interface_checker_board.html#aecae37d675e873ae2cb6c56cb9b16813',1,'CheckerBoard']]],
  ['removefromparent',['removeFromParent',['../interface_c_c_node.html#ad2d43e047941be667b57c71e1389bede',1,'CCNode']]],
  ['reorient',['reorient',['../interface_u_i_view.html#ab24caaf52d26c31dbf0ee835c2e2a76f',1,'UIView']]],
  ['resourceexists_3a',['resourceExists:',['../interface_k_i_t_app.html#abefaa1b8388601e28b9ff9c01b7a0fdd',1,'KITApp']]],
  ['resumeapp',['resumeApp',['../interface_k_i_t_app.html#abc9dbe4f4d4d0f7b7f27547c3e3fd448',1,'KITApp']]],
  ['reversearray',['reverseArray',['../interface_n_s_mutable_array.html#a85fb6d68e6ee7725a0b3b82cf3a10bca',1,'NSMutableArray']]],
  ['rotateapp_3a',['rotateApp:',['../interface_k_i_t_app.html#a9c10c1e073fb7f9e589549233c02cfce',1,'KITApp']]],
  ['runscene_3a',['runScene:',['../interface_k_i_t_app.html#ae1166feb9c56e79c10255385f9d2a811',1,'KITApp']]]
];
