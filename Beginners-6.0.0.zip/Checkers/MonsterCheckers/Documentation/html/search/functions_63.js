var searchData=
[
  ['capitalize_3a',['capitalize:',['../interface_n_s_string.html#ab2321644c463327da240e4e497661cf5',1,'NSString']]],
  ['centralize_3a',['centralize:',['../interface_k_i_t_app.html#a6c69263bce536e4a3b6b6d64b38d810c',1,'KITApp']]],
  ['chooseresource_3a',['chooseResource:',['../interface_k_i_t_app.html#af8dccce69df0325a16ae0a28d8d85c36',1,'KITApp']]],
  ['chooseresource_3ahdsuffix_3a',['chooseResource:hdSuffix:',['../interface_k_i_t_app.html#a91f40bed84f3f6aed521ea1cdc3d2cb8',1,'KITApp']]],
  ['classname',['className',['../interface_n_s_object.html#aa79b8d804d172bc8719d28f0c3c80a55',1,'NSObject']]],
  ['clear',['clear',['../interface_k_i_t_settings.html#a27acb9ce807eb3de19e16575be1df71f',1,'KITSettings']]],
  ['containstouch_3a',['containsTouch:',['../interface_touchable_node.html#a60960ff5fc94b2be2e2fa7c7a06fc623',1,'TouchableNode']]],
  ['copyanimations_3atokey_3anumframes_3adelay_3a',['copyAnimations:toKey:numFrames:delay:',['../interface_k_i_t_profile.html#a7a4d89b6095a14638725dd2a354aaeb7',1,'KITProfile']]],
  ['createmovepoint_3a',['createMovePoint:',['../interface_checker_board.html#af0f3f96c8ce65fc3395accfdbb609096',1,'CheckerBoard']]],
  ['currenttimeinseconds',['currentTimeInSeconds',['../interface_k_i_t_app.html#a14a951757c1a4c0a2699d7da7ca32252',1,'KITApp']]]
];
