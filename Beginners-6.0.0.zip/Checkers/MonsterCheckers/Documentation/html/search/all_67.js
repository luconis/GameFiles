var searchData=
[
  ['get',['get',['../interface_k_i_t_settings.html#a1998d6fa323251454699beb36b437678',1,'KITSettings']]],
  ['getpieceatxy_3a',['getPieceAtXY:',['../interface_checker_board.html#ab732cbae8d15d2f1101d1f589ba94b9f',1,'CheckerBoard']]],
  ['glow_3a',['glow:',['../interface_c_c_sprite.html#a864423caa0ae7f75319c42535b9dbab4',1,'CCSprite']]]
];
