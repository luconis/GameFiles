var searchData=
[
  ['currentteam',['currentTeam',['../interface_checker_board.html#ae6ba22a7fc2cb48a60b5df4040ea0b01',1,'CheckerBoard']]],
  ['currentxy',['currentXY',['../interface_checker_piece.html#a0ab90b6a9a93053ed03d9e3feae50149',1,'CheckerPiece']]]
];
