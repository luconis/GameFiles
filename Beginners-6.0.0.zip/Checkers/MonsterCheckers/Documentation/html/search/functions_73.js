var searchData=
[
  ['savesettings_3a',['saveSettings:',['../interface_k_i_t_settings.html#a447e5e6b897707713117b3b30cfec039',1,'KITSettings']]],
  ['scale_3a',['scale:',['../interface_k_i_t_app.html#ae925e80d2948b25d6de63331c5522089',1,'KITApp']]],
  ['setcolor_3a',['setColor:',['../interface_checker_piece.html#a49329eefd022054e6b1ca0879c76822e',1,'CheckerPiece']]],
  ['setdisplayframename_3a',['setDisplayFrameName:',['../interface_c_c_sprite.html#a218841c8ae6e93e11d5d6112df34ba71',1,'CCSprite']]],
  ['setframe_3a',['setFrame:',['../interface_c_c_sprite.html#a5b06a71802962d80f01eb33ebd690417',1,'CCSprite']]],
  ['settouchsize_3axscale_3ayscale_3a',['setTouchSize:xScale:yScale:',['../interface_touchable_node.html#a91d107aae2de7bc510adad38526f7ad4',1,'TouchableNode']]],
  ['setvolume_3avolume_3a',['setVolume:volume:',['../interface_k_i_t_sound.html#a64ada189ead726d53cfe331df1f9c014',1,'KITSound']]],
  ['sharedsound',['sharedSound',['../interface_k_i_t_sound.html#a3db9ef09f07f00dc725e97c775e2631c',1,'KITSound']]],
  ['sizefromwidthkey_3aheightkey_3a',['sizeFromWidthKey:heightKey:',['../interface_n_s_dictionary.html#af2c0428f89efcf2daf8cb2fdb574e4e6',1,'NSDictionary']]],
  ['spriteframeexists_3a',['spriteFrameExists:',['../interface_k_i_t_app.html#a595fd0d6494bda97761ac01633bc78ef',1,'KITApp']]],
  ['spriteframeforkey_3a',['spriteFrameForKey:',['../interface_k_i_t_profile.html#a58e6ae49cb7276e30b93f8ef85c717e9',1,'KITProfile']]],
  ['spriteframeforkey_3aindex_3a',['spriteFrameForKey:index:',['../interface_k_i_t_profile.html#a18c28707bec3e9a5e0a17adf907383a9',1,'KITProfile']]],
  ['startapp',['startApp',['../interface_k_i_t_app.html#ae088bd81de8f0161854521103a223ff6',1,'KITApp']]],
  ['stopapp',['stopApp',['../interface_k_i_t_app.html#af54772243e8626a4e74cb878b4de139f',1,'KITApp']]],
  ['stopsound_3a',['stopSound:',['../interface_k_i_t_sound.html#af37f73d797e6789c8f09cb1fb268b5b8',1,'KITSound']]]
];
