var searchData=
[
  ['panic',['panic',['../interface_checker_board.html#ac88e2133d7549388bc710b9b9531dd4b',1,'CheckerBoard::panic()'],['../interface_checker_piece.html#a239434a9da6d57a9927b72b02206881e',1,'CheckerPiece::panic()']]],
  ['pauseapp',['pauseApp',['../interface_k_i_t_app.html#af617bfd07930c49f7bc8d9efab4a9661',1,'KITApp']]],
  ['playpickupsound',['playPickupSound',['../interface_checker_piece.html#a50f5b1fb239359ad0ca656797b02394d',1,'CheckerPiece']]],
  ['playsound_3a',['playSound:',['../interface_k_i_t_profile.html#a5183e0caa155d65ffcccdaf513aa932e',1,'KITProfile::playSound:()'],['../interface_k_i_t_sound.html#a3ff64805dfc261b1523708ba4eaeb6d6',1,'KITSound::playSound:()']]],
  ['playsound_3adistancesq_3a',['playSound:distanceSQ:',['../interface_k_i_t_profile.html#a7c662602943746d7aac3b1dafe440421',1,'KITProfile::playSound:distanceSQ:()'],['../interface_k_i_t_sound.html#a3b58157fb19f495cbc7c4ad3fdce7a8a',1,'KITSound::playSound:distanceSQ:()']]],
  ['playsound_3avolume_3apan_3apitch_3aloop_3agroup_3a',['playSound:volume:pan:pitch:loop:group:',['../interface_k_i_t_sound.html#a872d2e60f0f6d08d4fa8ce25df41dbc3',1,'KITSound']]],
  ['playsound_3avolume_3apan_3apitch_3asolo_3a',['playSound:volume:pan:pitch:solo:',['../interface_k_i_t_profile.html#add505dd7145f5e165ff68aee803a95d4',1,'KITProfile']]],
  ['playsoundsolo_3a',['playSoundSolo:',['../interface_k_i_t_profile.html#ac58e8e4a3e9d2ccc0f7adf912fd5285d',1,'KITProfile']]],
  ['pointfromxkey_3aykey_3a',['pointFromXKey:yKey:',['../interface_n_s_dictionary.html#ac2f0b96a9d197d6017f7e252bfca60ad',1,'NSDictionary']]],
  ['pointfromxproperty_3ayproperty_3a',['pointFromXProperty:yProperty:',['../interface_c_c_t_m_x_layer.html#a48fea6a6ccbbb4d96f47400e28493acf',1,'CCTMXLayer']]],
  ['positiontoxy_3a',['positionToXY:',['../interface_checker_board.html#ae74945a7bf754ec50c4d75445baf63af',1,'CheckerBoard']]],
  ['processtouchbegan_3a',['processTouchBegan:',['../interface_touchable_node.html#a4a64a109c36f5a6378cbb6b90860f8d1',1,'TouchableNode']]],
  ['processtouchended_3a',['processTouchEnded:',['../interface_touchable_node.html#aecfe667bffee7c75bfe27de465d93a2f',1,'TouchableNode']]],
  ['profilewithname_3a',['profileWithName:',['../interface_k_i_t_profile.html#a363dd0964a15bc0746db8d4672cd204c',1,'KITProfile']]],
  ['purge',['purge',['../interface_k_i_t_profile.html#aa8c80bf502b830986b68211f4f0bd28f',1,'KITProfile::purge()'],['../interface_k_i_t_settings.html#a889987dd678abf28b2ef02ac870ffbf5',1,'KITSettings::purge()'],['../interface_k_i_t_sound.html#a8508774a2bd403425e28356adf274f61',1,'KITSound::purge()']]]
];
