var searchData=
[
  ['defaultattributeforkey_3a',['defaultAttributeForKey:',['../interface_k_i_t_profile.html#a0ce86c68e5b73c53fbeaa31e16466254',1,'KITProfile']]],
  ['defaultattributes',['defaultAttributes',['../interface_k_i_t_profile.html#ab78800f21644eaa70bcc785a011a2fd0',1,'KITProfile']]],
  ['dictionary',['dictionary',['../interface_k_i_t_settings.html#a931c056096747958d7c42243df5f8e76',1,'KITSettings']]],
  ['directionfromxy_3ato_3a',['directionFromXY:to:',['../interface_checker_board.html#ab060ac0f06989a8ac2353849ec6d268f',1,'CheckerBoard']]]
];
