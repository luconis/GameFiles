var searchData=
[
  ['addlabelbmfont_3astring_3aposition_3ascale_3aalignment_3az_3a',['addLabelBMFont:string:position:scale:alignment:z:',['../interface_c_c_node.html#aab669d5ee812723ad85b9eef33bf09f0',1,'CCNode']]],
  ['alldefaultattributekeys',['allDefaultAttributeKeys',['../interface_k_i_t_profile.html#a7c2dec16a2b61229dd11d312945845b2',1,'KITProfile']]],
  ['anchoroffset',['anchorOffset',['../interface_c_c_sprite.html#a0f2295dc1807a9bddfec1ae7f110efb3',1,'CCSprite']]],
  ['animate_3atag_3arepeat_3arestore_3a',['animate:tag:repeat:restore:',['../interface_c_c_sprite.html#a4edabe801376fa27625bb1ff52299229',1,'CCSprite']]],
  ['animateattack_3a',['animateAttack:',['../interface_checker_piece.html#a84b9a32a9ced868fe30fa8097ab4150e',1,'CheckerPiece']]],
  ['animatecurrentteam_3a',['animateCurrentTeam:',['../interface_checker_piece.html#a240dcc8986a97fdbd9586a469dc0732c',1,'CheckerPiece']]],
  ['animatedeath_3a',['animateDeath:',['../interface_checker_piece.html#a385f98cd54ca03cf373985bff495e8c0',1,'CheckerPiece']]],
  ['animatevictory_3a',['animateVictory:',['../interface_checker_piece.html#aff8648bd0892b15f8e27fc4a9d4389d7',1,'CheckerPiece']]],
  ['animationforkey_3a',['animationForKey:',['../interface_k_i_t_profile.html#a36484812b83cef3cbaa0b221b8760ee2',1,'KITProfile']]],
  ['animationforkey_3aindex_3a',['animationForKey:index:',['../interface_k_i_t_profile.html#a1ddd5ce1ebc0392fc96a9666e7c4fce5',1,'KITProfile']]],
  ['animations',['animations',['../interface_k_i_t_profile.html#a6ebf8f62a5945015e2b6a4b0ccf44feb',1,'KITProfile']]],
  ['array',['array',['../interface_k_i_t_sprite_frame_array.html#a41bf399eba77a6dfb00c29b07168eb26',1,'KITSpriteFrameArray']]]
];
