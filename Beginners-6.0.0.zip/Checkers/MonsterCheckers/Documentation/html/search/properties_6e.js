var searchData=
[
  ['name',['name',['../interface_checker_piece.html#abd56f4977e1ca4639e92f8a74e14c571',1,'CheckerPiece']]]
];
