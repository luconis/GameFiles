var searchData=
[
  ['kills',['kills',['../interface_checker_piece.html#a9da8d7fdacd62b049a4a414064917677',1,'CheckerPiece']]]
];
