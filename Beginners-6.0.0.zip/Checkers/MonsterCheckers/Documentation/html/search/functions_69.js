var searchData=
[
  ['idiom',['idiom',['../interface_k_i_t_app.html#a9ba0d5ce7efcdc0ee735bb52a4709f47',1,'KITApp']]],
  ['initfromnormalspriteframename_3aselected_3adisabled_3atarget_3aselector_3a',['initFromNormalSpriteFrameName:selected:disabled:target:selector:',['../interface_c_c_menu_item_sprite.html#a07f0418e2b0e113d5811d3332b976e06',1,'CCMenuItemSprite']]],
  ['initwithchildclass_3a',['initWithChildClass:',['../interface_c_c_scene.html#a1155adad5745dc689fcc939edb255207',1,'CCScene']]],
  ['initwithformat_3asubstring_3aframecount_3a',['initWithFormat:subString:frameCount:',['../interface_k_i_t_sprite_frame_array.html#acffd0d4212135110221a9145d175fc63',1,'KITSpriteFrameArray']]],
  ['initwithformat_3asubstring_3aframecount_3adelay_3a',['initWithFormat:subString:frameCount:delay:',['../interface_c_c_animation.html#a508b9b9d89078cd0304d9e9eaac1d92f',1,'CCAnimation']]],
  ['intvaluefromproperty_3a',['intValueFromProperty:',['../interface_c_c_t_m_x_layer.html#a9c382229588324b42db1829332395745',1,'CCTMXLayer']]],
  ['isalive',['isAlive',['../interface_checker_piece.html#a9bb95dbfa3279e83c2582c8020d265dd',1,'CheckerPiece']]],
  ['isdoneloading',['isDoneLoading',['../interface_k_i_t_sound.html#ac8b92c7c7d60b5f2bbe636da1e3dfd5f',1,'KITSound']]],
  ['ishd',['isHD',['../interface_k_i_t_app.html#a82e938bb821ec57d71862e0c6fca2bb1',1,'KITApp']]],
  ['ishdnonretina',['isHDNonRetina',['../interface_k_i_t_app.html#aff65f789cb02b408765a92f47b3a8567',1,'KITApp']]],
  ['isjumpfrom_3ato_3a',['isJumpFrom:to:',['../interface_checker_board.html#aa523c9942e4d825fe35cca9521b8a320',1,'CheckerBoard']]],
  ['islowercase',['isLowercase',['../interface_n_s_string.html#a8e263c1eb1e66cff14641e69a1a20c4d',1,'NSString']]],
  ['ispointwithinboundingbox_3a',['isPointWithinBoundingBox:',['../interface_c_c_node.html#af5010fc8752c317a44a889b21d1a1343',1,'CCNode']]],
  ['isretinaenabled',['isRetinaEnabled',['../interface_k_i_t_app.html#a4ad1f6f40dc5bdb083785553e0a0ae29',1,'KITApp']]],
  ['isvalidxy_3a',['isValidXY:',['../interface_checker_board.html#a14555f12fd6535ddbb433b7f217977d7',1,'CheckerBoard']]]
];
