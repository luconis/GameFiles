//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "MonsterCheckers.h"

///
/// Contains the logic for running the checker board and contains all the CheckerPiece objects
///
@interface CheckerBoard : CCLayer
	{
		CCSprite* checkerBoard,*logo,*credits;
		CCLayerColor* dimmer;
		NSMutableArray* checkerPieces,*movePoints;
		CheckerPiece* movingPiece;
		int currentTeam;
		double totalGameTime,moveTime,lastPanicTime,fartCooldown;
		CCAnimation* movePointAnimation;
		CGPoint bottomLeft,topRight;
		float yTileHeight,xTileWidth;
		BOOL playedIntro,farted;
		CCLabelBMFont* teamOneLabel,*teamTwoLabel,*vsLabel;
		BOOL hasMusic;
		ALuint musicId;
	}
	
	/// The current team number which has control of play
	@property (readonly,nonatomic) int currentTeam;
	/// The CheckerPiece which is currently being moved, nil by default
	@property (readonly,nonatomic) CheckerPiece* movingPiece;

	/// Returns the CheckerPiece object at the specified X,Y checker board coordinate
	-(CheckerPiece*) getPieceAtXY:(CGPoint)xy;
	/// Kills the CheckerPiece object at the specified X,Y checker board coordinate, given the attacker
	-(void) killPieceAtXY:(CGPoint)xy attacker:(CheckerPiece*)attacker;
	/// Creates a move point animation at the given X,Y checker board coordinate
	-(void) createMovePoint:(CGPoint)xy;
	/// Removes all existing move point animations
	-(void) removeAllMovePoints;
	/// Causes all the CheckerPiece objects to panic; used when shaking the device
	-(void) panic;

	/// Translates an X,Y checker board coordinate to a point-based position
	-(CGPoint) xyToPosition:(CGPoint)xy;
	/// Translates a point-based position to an X,Y checker board coordinate
	-(CGPoint) positionToXY:(CGPoint)pos;
	/// Returns YES if the X,Y checker board coordinate is valid
	+(BOOL) isValidXY:(CGPoint)xy;
	/// Returns YES if the CheckerPiece move from one X,Y checker board coordinate to another is a jump
	+(BOOL) isJumpFrom:(CGPoint)fromXY to:(CGPoint)toXY;
	/// Returns the integer compass direction a CheckerPiece would face when standing at one X,Y
	/// checker board coordinate and looking at another coordinate
	+(int) directionFromXY:(CGPoint)fromXY to:(CGPoint)toXY;

@end
