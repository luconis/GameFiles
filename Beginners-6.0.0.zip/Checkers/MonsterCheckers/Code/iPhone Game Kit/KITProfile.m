//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "iPhoneGameKit.h"

static BOOL _debug = NO;

// cache and re-use profiles here
// (speeds up loading by about 0.06s per re-used profile on a 3gs)
static NSMutableDictionary* profiles = nil;
//static KITProfile* defaultProfile = nil;


// private methods
@interface KITProfile ()
	-(id) initWithName:(NSString*)name;
	-(void) loadSpritesheets:(NSArray*)spritesheets;
	-(void) loadSpriteFrames:(NSDictionary*)dict;
	-(void) loadSpriteFramesForKey:(NSString*)key format:(NSString*)format frameCount:(int)frameCount;
	-(void) loadAnimations:(NSDictionary*)dict;
	-(void) loadAnimation:(NSString*)key dict:(NSDictionary*)dict;
	-(void) loadSounds:(NSArray*)ra;
	-(NSString*) getSoundForKey:(NSString*)key;
@end


@implementation KITProfile

#pragma mark -
#pragma mark Caching

	+(KITProfile*) profileWithName:(NSString*)name
	{
		// auto-create the profiles cache
		if( profiles == nil )
			profiles = [[NSMutableDictionary alloc] init];
		
		// see if this profile exists already
		KITProfile* profile = [profiles objectForKey:name];
		if( profile == nil )
		{
			@try
			{
				if(_debug) KITLog(@"Profile: loading %@", name);
				
				// create the profile & save for re-use
				profile = [[KITProfile alloc] initWithName:name];
				if( profile != nil )
					[profiles setObject:profile forKey:name];
				[profile release]; // ok because setObject retains
				
				// re-get it from cache (avoids using autorelease & potential memory leaks)
				profile = [profiles objectForKey:name];
			}
			@catch(NSException* exception)
			{
				KITLog(@"profileWithName exception: %@: %@", [exception name], [exception reason]);
			}
		}

		return profile;
	}
	
	+(void) purge
	{
		[profiles release];
		profiles = nil;
	}

#pragma mark -
#pragma mark Attributes

	-(NSArray*) allDefaultAttributeKeys
	{
		return [defaultAttributes allKeys];
	}

	-(id) defaultAttributeForKey:(NSString*)key
	{
		return [defaultAttributes objectForKey:key];
	}
/*
	-(id) defaultAttributeForKey:(NSString*)key
	{
		// return the default attribute
		id attribute = [defaultAttributes objectForKey:key];
		if( attribute != nil )
			return attribute;
		
		if( self != defaultProfile )
		{
			// make sure we have the default profile
			if( defaultProfile == nil )
				defaultProfile = [[self class] profileWithName:@"default"];
		
			// return the default profile's attribute
			return [defaultProfile defaultAttributeForKey:key];
		}
		
		return nil;
	}
*/
#pragma mark -
#pragma mark Sprite frames

	-(CCSpriteFrame*) spriteFrameForKey:(NSString*)key
	{
		return [self spriteFrameForKey:key index:0];
	}

	-(CCSpriteFrame*) spriteFrameForKey:(NSString*)key index:(int)index
	{
		NSMutableArray* spriteFrames = [sprites objectForKey:key];
		//KITAssert([spriteFrames isKindOfClass:[NSArray class]], @"Called spriteFrameForKey:index: when object at this key+index is not an array. Check your profile .plist or spriteFrameForKey call.");
		CCSpriteFrame* spriteFrame = [spriteFrames objectAtIndex:index];
		//KITAssert3(spriteFrame != nil, @"Sprite frame '%@.%d' does not exist for profile '%@'", key, index, title);
		return spriteFrame;
	}
		
#pragma mark -
#pragma mark Animations

	-(CCAnimation*) animationForKey:(NSString*)key
	{
		CCAnimation* animation = [animations objectForKey:key];
		KITAssert3([animation isKindOfClass:[CCAnimation class]], @"Called %@'s animationForKey: when object at key '%@' is not a CCAnimation. Check your profile .plist or animationForKey call. %@", title, key, animation);
		KITAssert2(animation != nil, @"Animation '%@' does not exist for profile '%@'", key, title);
		return animation;
	}

	-(CCAnimation*) animationForKey:(NSString*)key index:(int)index
	{
		// return just the CCAnimation?
		id animationArray = [animations objectForKey:key];
		if( [animationArray isKindOfClass:[CCAnimation class]] )
			return animationArray;
		
		// check that it is an array
		if( ![animationArray isKindOfClass:[NSArray class]] )
		{
			KITLog(@"Called animationForKey:index: when object at '%@.%d' is not an array. Check your profile %@.plist or animationForKey call.", key, index, title);
			return nil;
		}
		
		// clamp the index within bounds
		if( index >= [animationArray count] )
		{
			KITLog(@"Animation '%@.%d' clamped to index %d for profile '%@'", key, index, [animationArray count] - 1, title);
			index = [animationArray count] - 1;
		}
		
		// return a CCAnimation in this array
		CCAnimation* animation = [animationArray objectAtIndex:index];
		if( animation == nil )
		{
			KITLog(@"Animation '%@.%d' does not exist for profile '%@'", key, index, title);
		}
		return animation;
	}
	
	-(BOOL) hasAnimation:(NSString*)key
	{
		return [[animations objectForKey:key] isKindOfClass:[CCAnimation class]];
	}

	-(BOOL) hasAnimation:(NSString*)key index:(int)index
	{
		return ([[animations objectForKey:key] isKindOfClass:[NSArray class]]
			&& [[[animations objectForKey:key] objectAtIndex:index] isKindOfClass:[CCAnimation class]]);
	}

	-(void) copyAnimations:(NSString*)key toKey:(NSString*)toKey numFrames:(int)numFrames delay:(float)delay
	{
		// check that the animation array to copy exists
		id animationArray = [animations objectForKey:key];
		if( [animationArray isKindOfClass:[NSArray class]] )
		{
			animationArray = [animationArray copy];
		}
		else
		{
			animationArray = [[NSMutableArray alloc] initWithObjects:animationArray, nil];
		}

		// create temporary arrays
		NSMutableArray* anims = [[NSMutableArray alloc] initWithCapacity:[animationArray count]];
		NSMutableArray* frames = [[NSMutableArray alloc] initWithCapacity:numFrames];
		for( CCAnimation* animationToCopy in animationArray )
		{
			// copy the amount of frames requested
			[frames removeAllObjects];
			for( int i=0; i < numFrames; i++ )
				[frames addObject:[animationToCopy.frames objectAtIndex:i]];

			// create the new animation and add it to our dictionary
			CCAnimation* animation = [[CCAnimation alloc] initWithAnimationFrames:frames delayPerUnit:delay loops:1];
			[anims addObject:animation];
			[animation release]; // ok because setValue retains
		}

		// save the animations and release temporary arrays
		[animations setValue:anims forKey:toKey];
		[anims release];
		[frames release];
		[animationArray release];
	}

#pragma mark -
#pragma mark Sounds

	-(void) playSound:(NSString*)key
	{
		[self playSound:key volume:1.0f pan:1.0f pitch:1.0f solo:NO];
	}

	-(void) playSound:(NSString*)key distanceSQ:(float)distanceSQ
	{
		NSString* fname = [self getSoundForKey:key];
		if( fname != nil )
		{
			currentSound = [[KITSound sharedSound] playSound:fname distanceSQ:distanceSQ];
		}
	}

	-(void) playSound:(NSString*)key volume:(float)volume pan:(float)pan pitch:(float)pitch solo:(BOOL)solo
	{
		// get the entry associated with this key
		NSString* fname = [self getSoundForKey:key];
		if( fname != nil )
		{
			// stop old effect
			if( solo && currentSound != CD_MUTE )
				[[KITSound sharedSound] stopSound:currentSound];
			
			// play the effect
			currentSound = [[KITSound sharedSound] playSound:fname volume:volume pan:pan pitch:pitch loop:NO group:kSoundGroupMultiple];
		}
	}

	-(void) playSoundSolo:(NSString*)key
	{
		[self playSound:key volume:1.0f pan:1.0f pitch:1.0f solo:YES];
	}

#pragma mark -
#pragma mark Instance methods

	-(id) initWithName:(NSString*)name
	{
		// load profile dictionary
		NSString* filename = [[NSString alloc] initWithFormat:@"%@ profile.plist",name];
		NSDictionary* dict = [[NSDictionary alloc] initWithContentsOfFile:[[CCFileUtils sharedFileUtils] fullPathFromRelativePath:filename]];
		BOOL isValid = ([dict count] > 0);
		
		if( isValid )
		{
			self = [super init];
			if(self != nil)
			{
				currentSound = CD_MUTE;
				title = [name retain];
				
				// load the default attributes
				defaultAttributes = [[NSMutableDictionary alloc] initWithDictionary:[dict objectForKey:@"attributes"]];
				
				// copy any missing default attributes
/*				if( ![name isEqualToString:@"default"] )
				{
					if( defaultProfile == nil )
						defaultProfile = [[self class] profileWithName:@"default"];
					for( NSString* key in [defaultProfile allDefaultAttributeKeys] )
					{
						id attribute = [self defaultAttributeForKey:key];
						if( attribute == nil )
							[defaultAttributes setValue:[defaultProfile defaultAttributeForKey:key] forKey:key];
					}
				}
*/				
				// load all sprite sheets
				[self loadSpritesheets:[dict valueForKey:@"spritesheets"]];
				
				// load all sprite frame arrays
				sprites = [[NSMutableDictionary alloc] init];
				[self loadSpriteFrames:dict];
				
				// load all animations
				animations = [[NSMutableDictionary alloc] init];
				[self loadAnimations:dict];

				// load the sound effects
				sounds = [[dict objectForKey:@"sounds"] retain];
				[self loadSounds:[sounds allValues]];
			}
		}

		[dict release];
		[filename release];

		return (isValid ? self : nil);
	}

	-(void) dealloc
	{
		[defaultAttributes release];
		[sounds release];
		[animations release];
		[sprites release];
		[title release];
		[super dealloc];
	}

	-(void) loadSpritesheets:(NSArray*)spritesheets
	{
		@try
		{
			// load each spritesheet
			CCSpriteFrameCache* cacher = [CCSpriteFrameCache sharedSpriteFrameCache];
			for(NSString* sheet in spritesheets)
			{
				KITAssert1([KITApp resourceExists:sheet], @"The spritesheet '%@' must exist in resources", sheet);
				[cacher addSpriteFramesWithFile:sheet];
			}
		}
		@catch (NSException* exception)
		{
			KITLog(@"loadSpritesheets exception: %@: %@", [exception name], [exception reason]);
		}
	}
	
	-(void) loadSpriteFrames:(NSDictionary*)dict
	{
		NSDictionary* spritesDict = [dict objectForKey:@"sprites"];
		for(NSString* key in [spritesDict allKeys])
		{
			id value = [spritesDict objectForKey:key];
			
			// if sprites entry is a string, load one frame
			if( [value isKindOfClass:[NSString class]] )
				[self loadSpriteFramesForKey:key format:value frameCount:1];
			
			// otherwise load it as a dictionary with a format and frameCount
			else if( [value isKindOfClass:[NSDictionary class]] )
			{
				[self loadSpriteFramesForKey:key format:[value valueForKey:@"format"]
					frameCount:[[value valueForKey:@"frameCount"] intValue]];
			}
		}
	}

	-(void) loadSpriteFramesForKey:(NSString*)key format:(NSString*)format frameCount:(int)frameCount
	{
		// assertions
		KITAssert2(frameCount >= 1, @"The number 'sprites.%@.frameCount' is required in the plist for: %@", key, title);
		KITAssert2([format length] >= 1, @"The string 'sprites.%@.format' is required in the plist for: %@", key, title);
		
		// create sprite frame array
		KITSpriteFrameArray* spriteFrames = [[KITSpriteFrameArray alloc] initWithFormat:format subString:nil frameCount:frameCount];
		[sprites setObject:spriteFrames.array forKey:key];
		[spriteFrames release]; // ok because setObject retains
	}

	-(void) loadAnimations:(NSDictionary*)dict
	{
		NSDictionary* animsDict = [dict objectForKey:@"animations"];
		for(NSString* key in [animsDict allKeys])
		{
			NSDictionary* dict = [animsDict objectForKey:key];
			[self loadAnimation:key dict:dict];
		}
	}
	
	-(void) loadAnimation:(NSString*)key dict:(NSDictionary*)dict
	{
		// get the details for this animation
		NSString* format = [dict valueForKey:@"format"];
		NSArray* directions = [dict valueForKey:@"directions"];
		int frameCount = [[dict valueForKey:@"frameCount"] intValue];
		float delay = [[dict valueForKey:@"delay"] floatValue];
		delay = (delay == 0.0f ? 0.05f : clampf(delay, 0.01f, 0.33f));
		if(_debug) KITLog(@"Profile: loading animation %@, format %@, frameCount %d, delay %.2f, directions %@", key, format, frameCount, delay, directions);

		// assertions
		KITAssert2(frameCount >= 1, @"The number 'animations.%@.frameCount' is required in the plist for: %@", key, title);
		KITAssert2([format length] >= 1, @"The string 'animations.%@.format' is required in the plist for: %@", key, title);

		// load an array of animations
		if( directions != nil )
		{
			NSMutableArray* anims = [[NSMutableArray alloc] init];
			for(NSString* dir in directions)
			{
				CCAnimation* animation = [[CCAnimation alloc]
					initWithFormat:format subString:dir frameCount:frameCount delay:delay];
				[anims addObject:animation];
				[animation release]; // ok because addObject retains
			}
			[animations setValue:anims forKey:key];
			[anims release]; // ok because setValue retains
		}
		
		// load one animation
		else
		{
			CCAnimation* animation = [[CCAnimation alloc]
				initWithFormat:format subString:nil frameCount:frameCount delay:delay];
			[animations setValue:animation forKey:key];
			[animation release]; // ok because setValue retains
		}
	}
	
	-(void) loadSounds:(NSArray*)ra
	{
		for(id o in ra)
		{
			// load all sounds in array recursively
			if( [o isKindOfClass:[NSArray class]] )
				[self loadSounds:o];
			
			// load this sound
			else if( [o isKindOfClass:[NSString class]] )
				[[KITSound sharedSound] loadSound:o];

			// run-time error
			else
				KITAssert1(NO, @"What's this sound '%@'? Expecting a string or array.", o);
		}
	}

	-(NSString*) getSoundForKey:(NSString*)key
	{
		id o = [sounds valueForKey:key];
		if( o != nil )
		{
			// if it's a string, then it's a string
			// if it's an array, then select a string at random
			return ([o isKindOfClass:[NSString class]] ? o : [(NSArray*)o randomObject]);
		}
		return nil;
	}

@end
