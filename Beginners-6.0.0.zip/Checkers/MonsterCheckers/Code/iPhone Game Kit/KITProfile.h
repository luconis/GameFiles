//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "iPhoneGameKit.h"

///
/// Loads all sprite sheets, sprite frames and sound effects for an object using a property list.
/// Animations, sprites frames, and sounds are referenced by key, which is the dictionary key for that property list entry.
///
@interface KITProfile : NSObject
	{
		/// The profile's title
		NSString* title;
		
		/// A dictionary of default attributes
		NSMutableDictionary* defaultAttributes;

		/// A dictionary of sprite frame arrays
		NSMutableDictionary* sprites;
		
		/// Animations are stored as a dictionary where each entry is either an
		/// array of animations (like varying compass directions), or just an animation
		NSMutableDictionary* animations;
		
		/// Sounds are stored as a dictionary where each entry is either an array
		/// of sound names to randomly choose or a single sound name
		NSDictionary* sounds;
		
		/// The currently playing sound
		ALuint currentSound;
	}
	
	/// Get a character profile by name and caches it (passing "zombie" as the name will load "zombie profile.plist")
	+(KITProfile*) profileWithName:(NSString*)name;

	/// Purge the cached character profiles (automatically called by KITApp)
	+(void) purge;
	
	/// Returns all the default attribute keys
	-(NSArray*) allDefaultAttributeKeys;

	/// Returns the default attribute for the given key
	-(id) defaultAttributeForKey:(NSString*)key;
	
	/// Returns the sprite frame for the given key
	-(CCSpriteFrame*) spriteFrameForKey:(NSString*)key;

	/// Returns the sprite frame for the given key and index
	-(CCSpriteFrame*) spriteFrameForKey:(NSString*)key index:(int)index;

	/// Returns the animation for a given key
	-(CCAnimation*) animationForKey:(NSString*)key;

	/// Returns the animation for a given key and index
	-(CCAnimation*) animationForKey:(NSString*)key index:(int)index;

	/// Returns YES if the profile has an animation for the given key
	-(BOOL) hasAnimation:(NSString*)key;

	/// Returns YES if the profile has an animation for the given key and index
	-(BOOL) hasAnimation:(NSString*)key index:(int)index;

	/// Copies the animations from one key to another
	-(void) copyAnimations:(NSString*)key toKey:(NSString*)toKey numFrames:(int)numFrames delay:(float)delay;

	/// Plays a sound by key
	-(void) playSound:(NSString*)key;

	/// Plays a sound by key, at a given distance squared
	-(void) playSound:(NSString*)key distanceSQ:(float)distanceSQ;

	/// Plays a sound by key, given detailed parameters
	-(void) playSound:(NSString*)key volume:(float)volume pan:(float)pan pitch:(float)pitch solo:(BOOL)solo;

	/// Plays a sound soloed, stopping all other sounds currently being played by this character profile
	-(void) playSoundSolo:(NSString*)key;
	
@end
