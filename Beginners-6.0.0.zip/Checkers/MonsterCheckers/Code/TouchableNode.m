//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "MonsterCheckers.h"

@interface TouchableNode () // private methods
	-(void) setTouchBox;
@end

@implementation TouchableNode

	@synthesize touchedOn;

	-(id) init
	{
		self = [super init];
		if( self != nil )
		{
			touchedOn = 0.0;

			// give some sort of initial size in case subclass forgets
			[self setTouchSize:CGSizeMake(10.0f, 10.0f) xScale:1.0f yScale:1.0f];
		}
		return self;
	}
	
#pragma mark -
#pragma mark Touch

	-(BOOL) containsTouch:(CGPoint)touchPoint
	{
		return CGRectContainsPoint(touchBox, touchPoint);
	}
	
	-(BOOL) processTouchBegan:(CGPoint)touchPoint
	{
		if( [self containsTouch:touchPoint] )
		{
			touchedOn = [KITApp currentTimeInSeconds];
			return [self touchBegan];
		}
		return NO;
	}
	
	-(BOOL) processTouchEnded:(CGPoint)touchPoint
	{
		if( [self containsTouch:touchPoint] )
		{
			touchedOn = [KITApp currentTimeInSeconds];
			//NSLog(@"touching bbox=%.2f,%.2f,%.2f,%.2f", touchBox.origin.x, touchBox.origin.y, touchBox.size.width, touchBox.size.height);
			
			return [self touchEnded];
		}
		return NO;
	}
	
	-(BOOL) touchBegan
	{
		// for subclasses to implement
		return YES;
	}

	-(BOOL) touchEnded
	{
		// for subclasses to implement
		return YES;
	}

#pragma mark -
#pragma mark Attributes

	-(void) setTouchSize:(CGSize)size xScale:(float)xScale yScale:(float)yScale
	{
		size.width = size.width * xScale;
		size.height = size.height * yScale;
		
		self.contentSize = size;

		// reset touch box
		[self setTouchBox];
	}

	// override setPosition so we can update our touch box
	-(void) setPosition:(CGPoint)p
	{
		// set position
		[super setPosition:p];

		// reset touch box
		[self setTouchBox];
	}
	
	-(void) setTouchBox
	{
		// set a box which represents the area which can be touched
		int w = self.contentSize.width * self.scale;
		int h = self.contentSize.height * self.scale;
		touchBox = CGRectMake(self.position.x - (w/2), self.position.y - (h/2), w, h);
	}

#pragma mark -
#pragma mark Debug

#if kDrawRectanglesAroundTouchableNodes == 1
	-(void) draw
	{
		glLineWidth(2.0f);
		if( ([KITApp currentTimeInSeconds] - touchedOn) < 1.0f )
			glColor4f(1, 0, 0, 1);
		else
			glColor4f(1, 1, 1, 1);

		// draw rectangle representing our touch box
		CGPoint points[4];
		points[0] = ccp(touchBox.size.width / -2.0f, touchBox.size.height / -2.0f);
		points[1] = ccp(touchBox.size.width / -2.0f, touchBox.size.height / 2.0f);
		points[2] = ccp(touchBox.size.width / 2.0f, touchBox.size.height / 2.0f);
		points[3] = ccp(touchBox.size.width / 2.0f, touchBox.size.height / -2.0f);
		ccDrawPoly(points, 4, YES);
		
		// reset line width & color as to not interfere with draw code in other nodes that draws lines
		glLineWidth(1.0f);
		glColor4f(1, 1, 1, 1);
	}
#endif

@end