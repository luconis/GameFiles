//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "MonsterCheckers.h"

///
/// A CCNode which can easily respond to touches
///
@interface TouchableNode : CCNode
	{
		CGRect touchBox;
		double touchedOn;
	}
	
	/// Time in seconds that the piece was touched
	@property (readonly,nonatomic) double touchedOn;
	
	/// Sets the touch area size and scales it by the given factors
	-(void) setTouchSize:(CGSize)size xScale:(float)xScale yScale:(float)yScale;
	
	/// Returns YES if the node contains the given point-based touch position
	-(BOOL) containsTouch:(CGPoint)touchPoint;

	/// Processes a begin touch event; returns YES if the given touch point applies to this node
	-(BOOL) processTouchBegan:(CGPoint)touchPoint;
	/// Processes an end touch event; returns YES if the given touch point applies to this node
	-(BOOL) processTouchEnded:(CGPoint)touchPoint;
	/// For subclasses to implement; this method is called when a touch has began that applies to this node
	-(BOOL) touchBegan;
	/// For subclasses to implement; this method is called when a touch has ended that applies to this node
	-(BOOL) touchEnded;
@end
