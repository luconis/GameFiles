//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "MonsterCheckers.h"

@class CheckerBoard;

///
/// A subclass of TouchableNode; contains a KITProfile, CCSprite, name, moveList, etc.
///
@interface CheckerPiece : TouchableNode
	{
		KITProfile* profile;
		CCSprite* sprite,*deathSmoke;
		int team,unit,kills,currentKills;
		BOOL isMoving,isKing,isDead,isDying;
		NSMutableArray* moveList;
		CGPoint currentXY,fromXY,hoverXY;
		CGPoint possibleMoves[4];
		NSString* name;
		CCLabelBMFont* nameTxt;
	}
	
	/// The name of this piece
	@property (readwrite,copy,nonatomic) NSString* name;
	/// The current X,Y checker board coordinate
	@property (readwrite,nonatomic) CGPoint currentXY;
	/// The team number that this piece belongs to
	@property (readwrite,nonatomic) int team;
	/// The unit number for this piece
	@property (readwrite,nonatomic) int unit;
	/// Number of kills
	@property (readonly,nonatomic) int kills;
	/// Whether or not the piece is dead
	@property (readonly,nonatomic) BOOL isDead;
	/// Whether or not the piece is dying
	@property (readonly,nonatomic) BOOL isDying;
	/// Whether or not the piece is a king
	@property (readonly,nonatomic) BOOL isKing;
	
	/// Called when the piece is first touched
	-(void) touch;
	/// Hovers the pieces over the specified point-based position
	-(void) hoverAt:(CGPoint)pos;
	/// Moves the piece to the specified point-based position
	-(BOOL) moveTo:(CGPoint)pos;
	/// Cause the piece to fart; returns YES if successful
	-(BOOL) fart;
	/// Cause the piece to panic; returns YES if successful
	-(BOOL) panic;

	/// Returns YES if the piece is alive
	-(BOOL) isAlive;

	/// Returns an integer representing the number of possible moves for this piece
	-(int) numberOfPossibleMoves;
	
	/// Animate an attack towards the specified compass direction
	-(void) animateAttack:(int)dir;
	/// Animate dying towards the specified compass direction
	-(void) animateDeath:(int)dir;
	/// Animate victory; the winner parameter specifies whether this piece is on the winning team
	-(void) animateVictory:(BOOL)winner;
	/// Animates the piece based on the given current team
	-(void) animateCurrentTeam:(int)currentTeam;
	/// Plays the piece's pickup sound
	-(void) playPickupSound;

	/// Set the theme color for this piece
	-(void) setColor:(ccColor3B)color;

@end
