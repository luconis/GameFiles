//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "MonsterCheckers.h"

@interface CheckerPiece () // private methods
	-(CGPoint) xyToPossibleXY:(CGPoint)xy;
	-(void) getPossibleMoves:(CGPoint*)moves movesCount:(int)movesCount;
	-(BOOL) isPossibleMove:(CGPoint)xy;
	-(CGPoint) getFromXY;
	-(CGPoint) closestPossibleMoveXY:(CGPoint)pos;
	-(BOOL) moveListHasXY:(CGPoint)xy;
	-(void) resetMoves;
	-(void) setSpriteScale:(float)factor;
	-(void) animateWiggle:(BOOL)wiggling;
	-(void) animateStand;
	-(void) animateDeathSmoke;
	-(void) animateKill:(int)numberOfKills;
	-(void) die;
	-(void) refreshNameLabel;
	-(void) hideNameLabel;
	-(void) playFartSound;
	-(void) playSwooshSound;
	-(void) playPanicSound;
	-(void) playVictorySound;
	-(void) playSound:(NSString*)name;
	-(float) getXFactor;
	-(float) getYFactor;
	-(float) getVolume;
	-(float) getPanning;
	-(float) getPitch;
	-(CheckerBoard*) getCheckerBoard;
@end

@implementation CheckerPiece

	@synthesize team,kills,unit,currentXY,isDead,isDying,isKing,name;

#pragma mark -
#pragma mark Instance methods

	-(id) init
	{
		self = [super init];
		if( self != nil )
		{
			profile = nil;
			unit = 0;
			team = kTeamOne;
			kills = currentKills = 0;
			isMoving = isKing = isDead = isDying = NO;
			currentXY = fromXY = hoverXY = CGPointMake(-1.0f, -1.0f);
			moveList = [[NSMutableArray alloc] init];
			
			// load sprite
			sprite = [[CCSprite alloc] initWithSpriteFrameName:@"spark-fountain-groundflow-yellow-strong-0000.png"];
			[sprite setVisible:NO];
			[self addChild:sprite z:1];
			
			// load death smoke
			deathSmoke = [[CCSprite alloc] initWithSpriteFrameName:@"spark-fountain-groundflow-yellow-strong-0003.png"];
			deathSmoke.opacity = 0;
			[self addChild:deathSmoke z:2];
			
			// load name text
			nameTxt = [[self addLabelBMFont:@"font.fnt" string:@""
				position:ccp(0.0f, 0.0f) scale:0.6f alignment:kAlignmentLeft z:1] retain];
			[self hideNameLabel];

			// set size so our touchable superclass knows how big we are
			[self setTouchSize:sprite.contentSize xScale:0.5f yScale:0.75f];
		}
		return self;
	}
	
	-(void) dealloc
	{
		[name release];
		[nameTxt release];
		[moveList release];
		[deathSmoke release];
		[sprite release];
		[profile release];
		[super dealloc];
	}

	-(CheckerBoard*) getCheckerBoard
	{
		return (CheckerBoard*)self.parent;
	}

	-(NSString*) description
	{
		return [NSString stringWithFormat:@"(%.0f,%.0f) Monster #%d, Team %@",
			currentXY.x, currentXY.y, unit, (team == kTeamOne ? @"Ono" : @"Deux")];
	}

#pragma mark -
#pragma mark Public methods

	// start moving this piece
	-(void) touch
	{
		[self playPickupSound];
		
		if( CCRANDOM_0_1() < 0.4f )
			[self playSound:@"touch"];

		[self setSpriteScale:1.1f];
		
		[self animateWiggle:NO];
		
		[self refreshNameLabel];
		[nameTxt setVisible:YES];
		
		[self.parent reorderChild:self z:25.0f];
	}

	// keep hovering
	-(void) hoverAt:(CGPoint)pos
	{
		isMoving = YES;
		
		// hover following touch
		self.position = ccp(pos.x, pos.y + [KITApp scale:60.0f]);
		
		// light up the way
		CGPoint toXY = [[self getCheckerBoard] positionToXY:pos];

		// uncomment the following line to reveal how positionToXY is working
		//self.position = [[self getCheckerBoard] xyToPosition:toXY];
		
		if( !CGPointEqualToPoint(toXY, hoverXY) && [self isPossibleMove:toXY] )
		{
			if( [moveList count] == 0)
				[[self getCheckerBoard] removeAllMovePoints];
			[[self getCheckerBoard] createMovePoint:toXY];
			
			// if it's a jump, then add to move list
			if( [CheckerBoard isJumpFrom:fromXY to:toXY]
			&& ![self moveListHasXY:toXY] )
			{
				[moveList addObject:[NSValue valueWithCGPoint:toXY]];
				KITLog(@"Move list is now %@", moveList);
			}
			
			// save this hover point so we don't think about it twice
			hoverXY = toXY;
		}

		// wiggle if hovering over a good spot!
		[self animateWiggle:CGPointEqualToPoint(hoverXY, toXY)];
	}

	// perform all moves with setXY
	-(BOOL) moveTo:(CGPoint)pos
	{
		BOOL ret = NO;
		CGPoint xy = [self closestPossibleMoveXY:pos];
		int oldKills = kills;

		// stop wiggling
		[self animateStand];
		
		// do move list
		if( [moveList count] > 0
		&& [self moveListHasXY:xy] )
		{
			[[KITSound sharedSound] playSound:@"Drop.caf"];

			//KITLog(@"Performing movelist %@", moveList);
			for(NSValue* val in moveList)
			{
				CGPoint tempXY = [val CGPointValue];
				self.currentXY = tempXY;
			}

			ret = YES;
		}
		
		// just move once
		else if( [self isPossibleMove:xy] )
		{
			[[KITSound sharedSound] playSound:@"Drop.caf"];

			self.currentXY = xy;
			ret = YES;
		}
		
		// else, return to original point
		else
		{
			[[KITSound sharedSound] playSound:@"Pickup.caf"];
			
			//KITLog(@"%.0f,%.0f is not a possible move", xy.x, xy.y);
			CGPoint toXY = currentXY;
			currentXY = CGPointMake(-1.0f, -1.0f);
			self.currentXY = toXY;
		}
		
		// either way, reset move list
		[self resetMoves];
		
		// kill dance
		currentKills = (kills - oldKills);
		[self animateKill:currentKills];
		
		isMoving = NO;

		return ret;
	}

	-(BOOL) isAlive
	{
		return (!isDying && !isDead);
	}

	// how many moves are possible for this piece?
	-(int) numberOfPossibleMoves
	{
		int numberOfMoves = 0;

		// iterate over possible moves
		CGPoint moves[4];
		[self getPossibleMoves:moves movesCount:4];
		for(int i = 0; i < 4; i++)
		{
			if( [CheckerBoard isValidXY:moves[i]] )
			{
				numberOfMoves++;
				//KITSLog(@"%.0f,%.0f is a valid move for %@", moves[i].x, moves[i].y, piece);
			}
		}
		
		return numberOfMoves;
	}
	
#pragma mark -
#pragma mark Movement

	// move piece to this xy, jumping and kinging on the way
	-(void) setCurrentXY:(CGPoint)xy
	{
		if( !CGPointEqualToPoint(xy, currentXY) )
		{
			// destroy a piece on the way?
			if( [CheckerBoard isValidXY:currentXY] 
			&& [CheckerBoard isJumpFrom:currentXY to:xy] )
			{
				// find halfway point
				CGPoint killXY = ccpAdd(ccpMult(ccpSub(xy, currentXY), 0.5f), currentXY);
				if( !CGPointEqualToPoint(killXY,xy) )
				{
					[[self getCheckerBoard] killPieceAtXY:killXY attacker:self];
					kills++;
				}
			}
			
			// move to this position
			self.position = [[self getCheckerBoard] xyToPosition:xy];
			currentXY = xy;
			[self.parent reorderChild:self z:(8 - xy.y)];
			
			// is a king now?
			if( (team == kTeamOne && xy.y == 7.0f) || (team == kTeamTwo && xy.y == 0.0f) )
			{
				if( !isKing )
				{
					isKing = YES;
					[self playSound:@"victory"];
				}
			}

			[self setSpriteScale:1.0f];
		}
	}
	
	// get the xy where the piece was from
	-(CGPoint) getFromXY
	{
		// either last move point, or current point
		return ( [moveList count] > 0
			? [[moveList objectAtIndex:([moveList count] - 1)] CGPointValue]
			: currentXY );
	}

	// look for the closest possible move to this position
	-(CGPoint) closestPossibleMoveXY:(CGPoint)pos
	{
		NSMutableArray* moves = [[NSMutableArray alloc] init];

		// add move list
		if( [moveList count] > 0 )
			[moves addObjectsFromArray:moveList];
		
		// add last hover point
		[moves addObject:[NSValue valueWithCGPoint:hoverXY]];
		
		// look for closest point
		CGPoint closestXY = CGPointMake(-1.0f,-1.0f);
		float closestDistance = 999.0f;
		for(NSValue* moveValue in moves)
		{
			CGPoint moveXY = [moveValue CGPointValue];
			CGPoint move = [[self getCheckerBoard] xyToPosition:moveXY];
			
			float distance = ccpDistance(pos, move);
			if( distance < closestDistance )
			{
				closestDistance = distance;
				closestXY = moveXY;
			}
		}
		
		[moves release];
		
		KITLog(@"Closest distance was %.1f at %.0f,%.0f", closestDistance, closestXY.x, closestXY.y);
		return (closestDistance < [KITApp scale:75.0f] ? closestXY : [[self getCheckerBoard] positionToXY:pos]);
	}
	
	// list the possible moves for this piece (used to determine if game is still playable)
	-(void) getPossibleMoves:(CGPoint*)moves movesCount:(int)movesCount
	{
		int i;
		float direction = (team == kTeamOne ? 1.0f : -1.0f);
		fromXY = [self getFromXY];

		for(i = 0; i < movesCount; i++)
			moves[i] = CGPointMake(-1.0f, -1.0f);

		// add regular moves
		if( movesCount >= 2 )
		{
			moves[0] = ccp(fromXY.x - 1.0f, fromXY.y + direction);
			moves[1] = ccp(fromXY.x + 1.0f, fromXY.y + direction);
		}
		
		// add king moves
		if( isKing && movesCount >= 4)
		{
			moves[2] = ccp(fromXY.x - 1.0f, fromXY.y - direction);
			moves[3] = ccp(fromXY.x + 1.0f, fromXY.y - direction);
		}
		
		// try each move
		for(i = 0; i < movesCount; i++)
			moves[i] = [self xyToPossibleXY:moves[i]];
	}
	
	// is this xy point a possible move?
	-(BOOL) isPossibleMove:(CGPoint)toXY
	{
		CGPoint moves[4];
		[self getPossibleMoves:moves movesCount:4];
		//KITLog(@"possible move to %.0f,%.0f from %.0f,%.0f", possibleMove.x, possibleMove.y, fromXY.x, fromXY.y);
		for(int i = 0; i < 4; i++)
		{
			if( [CheckerBoard isValidXY:moves[i]] && CGPointEqualToPoint(toXY, moves[i]) )
			{
				KITLog(@"Possible move #%d to %.0f,%.0f is legit", i, moves[i].x, moves[i].y);
				return YES;
			}
		}
		
		return NO;
	}
	
	// convert this xy point to a possible xy move or jump
	-(CGPoint) xyToPossibleXY:(CGPoint)xy
	{
		CGPoint ret = CGPointMake(-1.0f, -1.0f);

		if( [CheckerBoard isValidXY:xy] )
		{
			// what piece is at that point?
			CheckerPiece* pieceAt = [[self getCheckerBoard] getPieceAtXY:xy];
			
			// clear?
			if( pieceAt == nil && [moveList count] == 0 )
				ret = xy;

			// jumpable?
			else if( pieceAt != nil && pieceAt.team != self.team )
			{
				CGPoint jumpXY = ccpAdd(ccpMult(ccpSub(xy, fromXY), 2.0f), fromXY);
				pieceAt = [[self getCheckerBoard] getPieceAtXY:jumpXY];
				if( pieceAt == nil)
					ret = jumpXY;
			}
		}
		
		return ret;
	}
	
	// see if move list has this point
	-(BOOL) moveListHasXY:(CGPoint)xy
	{
		// check move list for a certain xy value
		for(NSValue* val in moveList)
		{
			CGPoint p = [val CGPointValue];
			if( p.x == xy.x && p.y == xy.y )
				return YES;
		}

		return NO;
	}
	
	// reset the move list
	-(void) resetMoves
	{
		[moveList removeAllObjects];
		[[self getCheckerBoard] removeAllMovePoints];
		hoverXY = CGPointMake(-1.0f, -1.0f);
	}

#pragma mark -
#pragma mark Animation
	
	-(void) animateStand
	{
		[sprite stopAllActions];

		// standing animation
		int dir = (team == kTeamOne ? 1 : 0);
		CCAnimation* anim = [profile animationForKey:@"stand" index:dir];
		[anim setDelayPerUnit:0.08f + (CCRANDOM_0_1() * 0.08f)];
		[sprite runAction:[CCRepeatForever actionWithAction:
			[CCAnimate actionWithAnimation:anim]]];
	}

	-(void) animateWiggle:(BOOL)wiggling
	{
		if( wiggling )
		{
			if( [sprite getActionByTag:kActionWiggle] == nil )
			{
				[sprite stopAllActions];
				[sprite animate:[profile animationForKey:@"wiggle"] tag:kActionWiggle repeat:YES restore:YES];
			}
		}
		else
		{
			if( [sprite getActionByTag:kActionHover] == nil )
			{
				[sprite stopAllActions];
				[sprite animate:[profile animationForKey:@"hover" index:0] tag:kActionHover repeat:YES restore:YES];
			}
		}
	}

	-(void) animateKill:(int)numberOfKills
	{
		[self refreshNameLabel];

		sprite.opacity = 255;

		// jump up and down, then hide this piece's name
		[self runAction:[CCSequence actions:
			[CCJumpBy actionWithDuration:(0.75f * numberOfKills)
				position:sprite.position height:[KITApp scale:25.0f] jumps:numberOfKills],
			[CCCallFunc actionWithTarget:self selector:@selector(hideNameLabel)],
			nil]];
	}
	
	-(void) animateDeathSmoke
	{
		[[KITSound sharedSound] playSound:@"Sizzle.caf"];

		// launch a poof of smoke
		deathSmoke.flipX = (rand() % 2 == 0);
		deathSmoke.scale = 1.1f;
		deathSmoke.opacity = 96;
		[deathSmoke runAction:[CCSpawn actions:
			[CCScaleBy actionWithDuration:2.0f scale:3.0f],
			[CCFadeTo actionWithDuration:3.0f opacity:0],
			nil]];
	}

	-(void) animateAttack:(int)dir
	{
		[sprite stopAllActions];
		
		CCAnimation* attackAnim = [profile animationForKey:@"attack" index:dir];
		
		// wait for drop sound, then play attacking noise
		[self runAction:[CCSequence actions:
			[CCDelayTime actionWithDuration:0.3f],
			[CCCallFunc actionWithTarget:self selector:@selector(playSwooshSound)],
			[CCDelayTime actionWithDuration:[attackAnim duration] - 0.3f + 0.1f],
			[CCCallFunc actionWithTarget:self selector:@selector(animateStand)],
			nil]];

		// animate the attack
		[sprite animate:attackAnim tag:kActionAttack repeat:NO restore:YES];
	}

	-(void) animateDeath:(int)dir
	{
		isDying = YES;

		[self playSound:@"death"];

		[sprite stopAllActions];

		// play dying animation, then fade out and release a poof of smoke
		[sprite runAction:[CCSequence actions:
			[CCDelayTime actionWithDuration:0.5f],
			[CCAnimate actionWithAnimation:
				[profile animationForKey:@"die" index:dir]],
			[CCSpawn actions:
				[CCFadeOut actionWithDuration:1.0f],
				[CCSequence actions:
					[CCDelayTime actionWithDuration:0.1f + (CCRANDOM_0_1() * 0.333f)],
					[CCCallFunc actionWithTarget:self selector:@selector(animateDeathSmoke)],
					nil],
				nil],
			[CCCallFunc actionWithTarget:self selector:@selector(die)],
			nil]];
	}
	
	-(void) animateVictory:(BOOL)winner
	{
		if( ![self isAlive] )
			return;

		[sprite stopAllActions];

		sprite.opacity = 255;

		if( !winner )
		{
			// fade out this loser
			deathSmoke.opacity = 0;
			[sprite runAction:[CCSequence actions:
				[CCFadeOut actionWithDuration:0.1f],
				nil]];
		}
		else
		{
			// wait a bit, then play victory sound
			[self runAction:[CCSequence actions:
				[CCDelayTime actionWithDuration:(CCRANDOM_0_1() * 4.0f)],
				[CCCallFunc actionWithTarget:self selector:@selector(playVictorySound)],
				nil]];
			
			// dance around, play victory sound, and swing this piece's weapon
			[sprite runAction:[CCSequence actions:
				[CCDelayTime actionWithDuration:(CCRANDOM_0_1() * 0.5f)],
					[CCCallFunc actionWithTarget:self selector:@selector(playSwooshSound)],
				[CCAnimate actionWithAnimation:[profile animationForKey:@"attack" index:(int)(CCRANDOM_0_1() * 3.0f)]],
					[CCDelayTime actionWithDuration:(CCRANDOM_0_1() * 0.5f)],
					[CCCallFunc actionWithTarget:self selector:@selector(playSwooshSound)],
				[CCAnimate actionWithAnimation:[profile animationForKey:@"attack" index:(int)(CCRANDOM_0_1() * 3.0f)]],
					[CCDelayTime actionWithDuration:(CCRANDOM_0_1() * 0.5f)],
					[CCCallFunc actionWithTarget:self selector:@selector(playSwooshSound)],
				[CCAnimate actionWithAnimation:[profile animationForKey:@"attack" index:(int)(CCRANDOM_0_1() * 3.0f)]],
					[CCDelayTime actionWithDuration:(CCRANDOM_0_1() * 0.5f)],
				[CCScaleTo actionWithDuration:1.0f scaleX:0.1f scaleY:0.1f],
				[CCFadeOut actionWithDuration:0.1f],
				nil]];
		}
	}
	
	// set opacity based on current team
	-(void) animateCurrentTeam:(int)currentTeam
	{
		if( [self isAlive] )
			sprite.opacity = (team == currentTeam ? 255 : 196);
	}

	-(BOOL) fart
	{
		if( [self isAlive] && !isMoving )
		{
			[sprite stopAllActions];
			
			// turn around momentarily and fart
			CCAnimation* turnedAround = [profile animationForKey:@"stand" index:(team == kTeamOne ? 0 : 1)];
			[sprite runAction:[CCSequence actions:
				[CCAnimate actionWithAnimation:turnedAround],
				[CCCallFunc actionWithTarget:self selector:@selector(playFartSound)],
				[CCAnimate actionWithAnimation:turnedAround],
				[CCCallFunc actionWithTarget:self selector:@selector(playVictorySound)],
				[CCAnimate actionWithAnimation:turnedAround],
				[CCCallFunc actionWithTarget:self selector:@selector(animateStand)],
				nil]];
			return YES;
		}
		return NO;
	}

	-(BOOL) panic
	{
		if( [self isAlive] && !isMoving )
		{
			CGPoint pos = self.position;
			[self runAction:[CCSequence actions:
				[CCMoveTo actionWithDuration:0.075f
					position:ccp(pos.x + (CCRANDOM_MINUS1_1() * [KITApp scale:15.0f]),
						pos.y + (CCRANDOM_MINUS1_1() * [KITApp scale:10.0f]))],
				[CCDelayTime actionWithDuration:CCRANDOM_0_1() * 0.5f],
				[CCCallFunc actionWithTarget:self selector:@selector(playPanicSound)],
				[CCMoveTo actionWithDuration:0.05f position:pos],
				nil]];
			return YES;
		}
		return NO;
	}
	
	-(void) playPickupSound
	{
		[[KITSound sharedSound] playSound:@"Pickup.caf"];
	}
	
	// set our colors
	-(void) setColor:(ccColor3B)color
	{
		[nameTxt setColor:color];
		[deathSmoke setColor:color];
	}

	// update our name label with current number of kills
	-(void) refreshNameLabel
	{
		if( kills <= 0 )
			[nameTxt setString:name];
		else
		{
			NSString* s = [[NSString alloc] initWithFormat:@"%@ +%d", name, kills];
			[nameTxt setString:s];
			[s release];
		}
		
		nameTxt.position = ccp((-nameTxt.contentSize.width / 2.0f) + [KITApp scale:15.0f], [KITApp scale:50.0f]);
	}

	-(void) hideNameLabel
	{
		[nameTxt setVisible:NO];
	}
	
	-(void) die
	{
		[sprite setVisible:NO];
		isDead = YES;
	}

#pragma mark -
#pragma mark Sound

	-(void) playSwooshSound
	{
		[[KITSound sharedSound] playSound:(currentKills > 1 ? @"Punch.caf" : (CCRANDOM_0_1() < 0.5f ? @"Swoosh1.caf" : @"Swoosh2.caf"))];
	}
	
	-(void) playVictorySound
	{
		[self playSound:@"victory"];
	}
	
	-(void) playFartSound
	{
		[self playSound:@"fart"];
	}
	
	-(void) playPanicSound
	{
		if( CCRANDOM_0_1() < 0.5f )
			[self playSound:@"panic"];
	}
	
	// play a sound with our current volume, panning, pitch, etc..
	-(void) playSound:(NSString*)s
	{
		[profile playSound:s volume:[self getVolume] pan:[self getPanning] pitch:[self getPitch] solo:YES];
	}

#pragma mark -
#pragma mark Attributes
	
	// set the piece's team
	-(void) setTeam:(int)newTeam
	{
		team = newTeam;
		
		// load character profile
		[profile release];
		profile = [[KITProfile profileWithName:(team == kTeamOne ? @"Death" : @"MonsterBlue")] retain];
		[profile copyAnimations:@"wiggle" toKey:@"hover" numFrames:1 delay:0.05f];
		
		// show the sprite
		[sprite setVisible:YES];
		
		// make monster start looking
		[self animateStand];
	}
	
	// scale our sprite based on y position, iDevice, and whether it is a king or not
	-(void) setSpriteScale:(float)factor
	{
		if( team == kTeamOne )
			factor *= 1.125f;
		sprite.scale = (((isKing ? 1.5f : 1.0f) - (0.15f * [self getYFactor])) * factor);
	}

	// used to determine panning
	-(float) getXFactor
	{
		return (self.position.x / [KITApp scale:480.0f]);
	}
	
	// used to determine panning
	-(float) getYFactor
	{
		return (self.position.y / [KITApp scale:320.0f]);
	}
	
	// volume is louder in the front & louder if a king
	-(float) getVolume
	{
		return ((isKing ? 1.0f : 0.95f) - ([self getYFactor] * 0.1f));
	}

	// panning based on x position
	-(float) getPanning
	{
		float xFactor = [self getXFactor];
		if( xFactor < 0.2f )
			return -0.01f;
		else if( xFactor > 0.8f )
			return 0.01f;
		return 0.0f;
	}

	// pitch deeper if a king
	-(float) getPitch
	{
		return (isKing ? 0.6f : 1.0f);
	}

@end
