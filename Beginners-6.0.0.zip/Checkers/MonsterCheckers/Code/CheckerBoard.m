//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "MonsterCheckers.h"


const ccColor3B kTeamOneColor = {255, 255, 128};
const ccColor3B kTeamTwoColor = {128, 255, 128};


// private methods
@interface CheckerBoard ()
	-(void) resetBoard;
	-(BOOL) isSwapping;
	-(void) swapTeams;
	-(void) nextGame;
	-(void) refreshTeamLabel:(int)team duration:(float)duration;
	-(void) showVersus;
	-(NSString*) getNameOfTeamOne;
	-(NSString*) getNameOfTeamTwo;
@end


@implementation CheckerBoard

	@synthesize currentTeam,movingPiece;

#pragma mark -
#pragma mark Instance methods

	-(id) init
	{
		self = [super init];
		if( self != nil )
		{
			// set this so we can register with touch dispatcher
			self.isTouchEnabled = YES;
			
			playedIntro = NO;
			farted = NO;
			totalGameTime = moveTime = lastPanicTime = 0;
			musicId = CD_MUTE;
			fartCooldown = 6.0f;
			
			// load sounds
			hasMusic = [KITApp resourceExists:@"Music.caf"];
			[[KITSound sharedSound] loadSound:@"MonsterCheckers.caf"];
			[[KITSound sharedSound] loadSound:@"Pickup.caf"];
			[[KITSound sharedSound] loadSound:@"Drop.caf"];
			[[KITSound sharedSound] loadSound:@"Swoosh1.caf"];
			[[KITSound sharedSound] loadSound:@"Swoosh2.caf"];
			[[KITSound sharedSound] loadSound:@"Punch.caf"];
			[[KITSound sharedSound] loadSound:@"Sizzle.caf"];

			// bottom left: 12.00,23.00
			// top left: 68.00,302.00
			// top right: 413.00,302.00
			// bottom right: 466.00,24.00
			bottomLeft = [KITApp centralize:ccp(-228.0f, -152.0f)];
			topRight = [KITApp centralize:ccp(173.0f, 127.0f)];
			yTileHeight = ((topRight.y - bottomLeft.y) / 8.0f);
			xTileWidth = ((topRight.x - bottomLeft.x) / 8.0f);

			// load background
			checkerBoard = [[CCSprite alloc] initWithFile:@"Board.png"];
			checkerBoard.position = [KITApp centralize:ccp(0,0)];
			[self addChild:checkerBoard z:1];

			// load dimmer
			dimmer = [[CCLayerColor alloc] initWithColor:ccc4(0, 0, 0, 164)];
			dimmer.scale = 4.0f;
			[self addChild:dimmer z:25];
			
			// load logo
			logo = [[CCSprite alloc] initWithFile:@"Logo.png"];
			logo.position = [KITApp centralize:ccp(0,110.0f)];
			[self addChild:logo z:50];
			
			// load credits
			credits = [[CCSprite alloc] initWithFile:@"Credits.png"];
			credits.position = [KITApp centralize:ccp(0,-50.0f)];
			[self addChild:credits z:50];
			
			// load animations
			movePointAnimation = [[CCAnimation alloc]
				initWithFormat:@"spark-fountain-groundflow-yellow-strong-00%02d.png"
				subString:nil frameCount:20 delay:0.04f];
			movePoints = [[NSMutableArray alloc] init];
			
			// load pieces
			checkerPieces = [[NSMutableArray alloc] initWithCapacity:24];
			[self resetBoard];
			
			// create labels
			teamOneLabel = [[self addLabelBMFont:@"font.fnt" string:@""
				position:CGPointZero scale:0.65f alignment:kAlignmentLeft z:10] retain];
			teamTwoLabel = [[self addLabelBMFont:@"font.fnt" string:@""
				position:CGPointZero scale:0.65f alignment:kAlignmentLeft z:10] retain];
			vsLabel = [[self addLabelBMFont:@"font.fnt" string:@"vs"
				position:[KITApp centralize:ccp(-20.0f, 0.0f)]
				scale:0.65f alignment:kAlignmentLeft z:10] retain];
			[teamOneLabel setColor:kTeamOneColor];
			[teamTwoLabel setColor:kTeamTwoColor];
			[vsLabel setColor:ccc3(128, 128, 128)];
			
			// load music
			if( hasMusic )
				[[KITSound sharedSound] loadSound:@"Music.caf"];
				
			// launch update loop
			[self schedule:@selector(update:) interval:0.2f];
		}
		return self;
	}
	
	-(void) dealloc
	{
		self.isTouchEnabled = NO;
		
		[teamTwoLabel release];
		[teamOneLabel release];
		[movePoints release];
		[movePointAnimation release];
		[checkerPieces release];
		[checkerBoard release];
		[dimmer release];
		[credits release];
		[logo release];
		[super dealloc];
	}
	
	// reinitialize the board with new pieces, start animations, etc.
	-(void) resetBoard
	{
		BOOL firstTime = ([checkerPieces count] == 0);
		
		NSMutableArray* names = [[NSMutableArray alloc] initWithObjects:
			@"Horace", @"Slag", @"Hairy", @"Booger", @"Scab",
			@"Rudolf", @"Furr", @"Grrr", @"Hallow", @"Roar",
			@"Barf", @"Spit", @"Vom", @"Horn", @"Mess",
			@"Gob", @"Marty", @"Curse", @"Eater", @"Whip",
			@"Pole", @"Argh", @"Whups", @"Caca", @"John",
			@"Slob", @"Peeyu", @"Orf", @"Cyclo", @"Wynn",
			@"Buster", @"Klack", @"Rizz", @"Moop", @"Trait",
			nil];
		srand([KITApp currentTimeInSeconds]);

		// reset state
		totalGameTime = 0.0f;
		currentTeam = kTeamOne;
		movingPiece = nil;

		// remove existing pieces
		for(CheckerPiece* piece in checkerPieces)
		{
			[self removeChild:piece cleanup:YES];
		}
		[checkerPieces removeAllObjects];

		// create new pieces
		int x = 0, y = 0, team = kTeamOne;
		for(int i = 0; i < 24; i++)
		{
			// create this checker piece and add it as a child
			CheckerPiece* checkerPiece = [[CheckerPiece alloc] init];
			[self addChild:checkerPiece z:(8 - y)];

			// set it up
			checkerPiece.team = team;
			checkerPiece.currentXY = ccp(x, y);
			checkerPiece.unit = i;
			[checkerPiece animateCurrentTeam:currentTeam];
			[checkerPiece setColor:(team == kTeamOne ? kTeamOneColor : kTeamTwoColor)];
			
			// give it a unique name
			NSString* name = [names randomObject];
			[checkerPiece setName:name];
			[names removeObject:name];

			// add to our list
			[checkerPieces addObject:checkerPiece];
			
			// fall from the sky
			CGPoint toPosition = checkerPiece.position;
			checkerPiece.position = ccp(toPosition.x, toPosition.y + [KITApp scale:320.0f]);
			[checkerPiece runAction:
				[CCSequence actions:
					[CCJumpTo actionWithDuration:1.0f + (CCRANDOM_0_1() * 1.5f)
						position:toPosition height:100.0f jumps:1],
					[CCCallFunc actionWithTarget:checkerPiece selector:@selector(playPickupSound)],
					nil]];
			
			// increase x,y to next open spot
			x += 2;
			if( x >= 8 )
			{
				// skip to next team
				if( y == 2 )
				{
					y = 5;
					team = kTeamTwo;
				}
				else
					y++;

				// odd rows are x + 1
				x = ((y % 2) == 0 ? 0 : 1);
			}
			
			// release it because addChild and addObject have both retained it
			[checkerPiece release];
		}
		
		if( !firstTime )
		{
			// show versus info
			[self runAction:[CCSequence actions:
				[CCDelayTime actionWithDuration:2.5f],
				[CCCallFunc actionWithTarget:self selector:@selector(showVersus)],
				nil]];
		}
		
		[names release];
	}
	
	// general update method
	-(void) update:(ccTime)delta
	{
		totalGameTime += delta;
		moveTime += delta;
		
		// hide the intro logo and credits
		if( totalGameTime > 4.0f && !playedIntro && [[KITSound sharedSound] playSound:@"MonsterCheckers.caf"] )
		{
			playedIntro = YES;
			[logo runAction:[CCSpawn actions:
				[CCMoveTo actionWithDuration:2.0f position:[KITApp centralize:ccp(0.0f, 250.0f)]],
				[CCFadeOut actionWithDuration:2.0f],
				nil
				]];
			[credits runAction:[CCSpawn actions:
				[CCMoveTo actionWithDuration:2.0f position:[KITApp centralize:ccp(0.0f, -250.0f)]],
				[CCFadeOut actionWithDuration:2.0f],
				nil
				]];
			[dimmer runAction:[CCFadeTo actionWithDuration:2.0f opacity:0]];
			[self runAction:[CCSequence actions:
				[CCDelayTime actionWithDuration:0.5f],
				[CCCallFunc actionWithTarget:self selector:@selector(showVersus)],
				nil]];
		}
		
		// fart
		if( totalGameTime > 10.0f
		&& moveTime > fartCooldown
		&& !farted
		&& ![self isSwapping]
		&& CCRANDOM_0_1() < 0.1f
		&& [[checkerPieces randomObject] fart] )
		{
			farted = YES;
			fartCooldown += 5.0f;
		}
		
		// play music
		if( hasMusic
		&& totalGameTime > 2.0f
		&& musicId == CD_MUTE )
		{
			musicId = [[KITSound sharedSound] playSound:@"Music.caf" volume:0.45f pan:0.0f pitch:1.0f loop:YES group:kSoundGroupSingle];
		}
	}

	// show player one vs player two labels
	-(void) showVersus
	{
		[vsLabel stopAllActions];
		[teamOneLabel stopAllActions];
		[teamTwoLabel stopAllActions];

		vsLabel.opacity = 0;
		teamOneLabel.opacity = 0;
		teamTwoLabel.opacity = 0;

		[teamOneLabel setString:[self getNameOfTeamOne]];
		[teamTwoLabel setString:[self getNameOfTeamTwo]];
		teamOneLabel.position = [KITApp centralize:ccp(-65.0f, 45.0f)];
		teamTwoLabel.position = [KITApp centralize:ccp(-65.0f, -45.0f)];

		// player one label sinks to bottom of screen to indicate who is player one
		[teamOneLabel runAction:[CCSequence actions:
			[CCFadeIn actionWithDuration:0.25f],
			[CCDelayTime actionWithDuration:1.5f],
			[CCMoveBy actionWithDuration:1.5f position:ccp(0.0f, [KITApp scale:-140.0f])],
			[CCFadeOut actionWithDuration:1.0f],
			nil]];
		
		// vs and player two labels just fade out
		[vsLabel runAction:[CCSequence actions:
			[CCFadeIn actionWithDuration:0.25f],
			[CCDelayTime actionWithDuration:1.5f],
			[CCFadeOut actionWithDuration:0.5f],
			nil]];
		[teamTwoLabel runAction:[CCSequence actions:
			[CCFadeIn actionWithDuration:0.25f],
			[CCDelayTime actionWithDuration:1.5f],
			[CCFadeOut actionWithDuration:0.5f],
			nil]];
	}

	// show the label for this team
	-(void) refreshTeamLabel:(int)team duration:(float)duration
	{
		CGSize iSize = [KITApp winSize];

		// get a pointer to this team label
		CCLabelBMFont* teamLabel = (team == kTeamOne ? teamOneLabel : teamTwoLabel);
		
		[teamLabel stopAllActions];
		
		teamLabel.opacity = 0;
		teamLabel.position = ccp([KITApp scale:15.0f],
			(team == kTeamOne ? [KITApp scale:45.0f] : iSize.height - [KITApp scale:52.0f]));
		
		// fade in, wait, then slide out
		[teamLabel runAction:[CCSequence actions:
			[CCFadeTo actionWithDuration:0.125f opacity:(team == currentTeam ? 255 : 192)],
			[CCDelayTime actionWithDuration:duration],
			[CCMoveBy actionWithDuration:0.69f position:ccp([KITApp scale:-250.0f], 0.0f)],
			nil]];
	}

	// swap play control to the other team
	-(void) swapTeams
	{
		currentTeam = (currentTeam == kTeamOne ? kTeamTwo : kTeamOne);
		moveTime = 0.0f;
		farted = NO;
		
		// analyze this team's pieces
		int teamOneScore = 0, teamTwoScore = 0;
		int numberOfPieces = 0, numberOfMoves = 0;
		for(CheckerPiece* piece in checkerPieces)
		{
			// determine each team's score
			int score = (piece.isKing ? 1 : 0) + piece.kills;
			if( piece.team == kTeamOne )
				teamOneScore += score;
			else
				teamTwoScore += score;

			// this piece might contribute to this team's status
			if( piece.team == currentTeam && [piece isAlive] )
			{
				// ok, this team has a piece
				numberOfPieces++;
				
				// test possible moves
				numberOfMoves += [piece numberOfPossibleMoves];
			}
		
			// update the team status while we are at it
			[piece animateCurrentTeam:currentTeam];
		}
		
		// show the new scores
		[teamOneLabel setString:[NSString stringWithFormat:@"%@\n%d points", [self getNameOfTeamOne], teamOneScore]];
		[teamTwoLabel setString:[NSString stringWithFormat:@"%@\n%d points", [self getNameOfTeamTwo], teamTwoScore]];
		[self refreshTeamLabel:kTeamOne duration:(currentTeam == kTeamOne ? 1.5f : 1.0f)];
		[self refreshTeamLabel:kTeamTwo duration:(currentTeam == kTeamTwo ? 1.5f : 1.0f)];
		KITLog(@"Team %d has %d pieces and %d possible moves", (currentTeam + 1), numberOfPieces, numberOfMoves);
		
		// next game?
		if( !numberOfPieces || !numberOfMoves )
			[self nextGame];
	}
	
	// launch the next game
	-(void) nextGame
	{
		KITLog(@"Next game!!!");
		
		// victory dance
		for(CheckerPiece* piece in checkerPieces)
			[piece animateVictory:(currentTeam != piece.team)]; // (current team is the loser)

		// show victorious team
		[self refreshTeamLabel:kTeamOne duration:(currentTeam == kTeamOne ? 1.0f : 4.0f)];
		[self refreshTeamLabel:kTeamTwo duration:(currentTeam == kTeamTwo ? 1.0f : 4.0f)];
		
		// reset the board after a bit
		CCAction* action = [CCSequence actions:
			[CCDelayTime actionWithDuration:4.5f],
			[CCCallFunc actionWithTarget:self selector:@selector(resetBoard)],
			nil];
		action.tag = kActionSwap;
		[self runAction:action];
	}
	
	-(NSString*) getNameOfTeamOne
	{
		return @"Player One";
	}

	-(NSString*) getNameOfTeamTwo
	{
		return @"Player Two";
	}


	-(BOOL) isSwapping
	{
		return ([self getActionByTag:kActionSwap] != nil);
	}

#pragma mark -
#pragma mark Public methods

	-(CheckerPiece*) getPieceAtXY:(CGPoint)xy
	{
		// look for piece at this xy
		if( [CheckerBoard isValidXY:xy] )
		{
			for(CheckerPiece* piece in checkerPieces)
			{
				if( [piece isAlive] && (int)piece.currentXY.x == (int)xy.x && (int)piece.currentXY.y == (int)xy.y )
					return piece;
			}
		}

		// no piece there
		return nil;
	}

	-(void) killPieceAtXY:(CGPoint)xy attacker:(CheckerPiece*)attacker
	{
		CheckerPiece* piece = [self getPieceAtXY:xy];
		if( piece != nil && attacker != nil && piece != attacker && piece.team != attacker.team )
		{
			// start attack animation
			[attacker animateAttack:[CheckerBoard directionFromXY:attacker.currentXY to:xy]];
			
			// launch death sequence
			[piece animateDeath:[CheckerBoard directionFromXY:xy to:attacker.currentXY]];
		}
	}

	// animate this move point
	-(void) createMovePoint:(CGPoint)xy
	{
		CGPoint pos = [self xyToPosition:xy];

		// if not already a move point
		for(CCSprite* sprite in movePoints)
		{
			if( CGPointEqualToPoint(sprite.position, pos) )
				return;
		}
		
		// create move point sprite
		CCSprite* sprite = [[CCSprite alloc] initWithSpriteFrameName:@"spark-fountain-groundflow-yellow-strong-0000.png"];
		sprite.position = ccp(pos.x, pos.y + [KITApp scale:20.0f]);
		sprite.scale = 1.33f;
		sprite.opacity = 164;
		[sprite setColor:(currentTeam == kTeamOne ? kTeamOneColor : kTeamTwoColor)];
		[self addChild:sprite z:(8 - xy.y)];
		
		// animate it
		[sprite runAction:[CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:movePointAnimation]]];
		
		// add to list
		[movePoints addObject:sprite];
		
		[sprite release];
	}
	
	-(void) removeAllMovePoints
	{
		for(CCSprite* sprite in movePoints)
		{
			[self removeChild:sprite cleanup:YES];
		}
		
		[movePoints removeAllObjects];
	}

	// cause the monster's to panic
	-(void) panic
	{
		double currentTime = [KITApp currentTimeInSeconds];
		double elapsed = currentTime - lastPanicTime;

		if( totalGameTime > 8.0f && elapsed > 3.0f )
		{
			lastPanicTime = currentTime;

			for( CheckerPiece* piece in checkerPieces )
				[piece panic];
		}
	}

	// convert checkerboard xy to a position
	// x = 0 thru 8, y = 0 thru 8, xy=(0,0) is bottom left
	-(CGPoint) xyToPosition:(CGPoint)xy
	{
		xy.x = (int)xy.x;
		xy.y = (int)xy.y;
		float yPercent = (xy.y / 8.0f);
		CGPoint p = ccp((xy.x - 3.5f) * (55.0f - (yPercent * 15.0f)),
			((xy.y - 3.0f) * 35.0f) + 15.0f - (yPercent * 5.0f));
		p = [KITApp centralize:p];
		//p = ccpMult(p, [KITApp scale:1.0f]);

		//KITLog(@"xy %.1f,%.1f is position %.1f,%.1f",xy.x,xy.y,p.x,p.y);				
		return p;
	}
	
	// calculate the nearest x,y coordinate from a point
	-(CGPoint) positionToXY:(CGPoint)pos
	{
		CGPoint xy = CGPointZero;

		xy.y = (int)clampf((((pos.y - bottomLeft.y) / yTileHeight) - 0.5f), 0.0f, 7.0f);
		xy.x = (int)clampf((((pos.x - bottomLeft.x) / xTileWidth) - 0.5f), 0.0f, 7.0f);
		
		return xy;
	}

	+(BOOL) isValidXY:(CGPoint)xy
	{
		BOOL isBlack = ((int)xy.y % 2 == 0
			? ((int)xy.x % 2 == 0)
			: ((int)xy.x % 2 == 1));

		return (isBlack
			&& xy.x >= 0.0f && xy.x <= 7.0f
			&& xy.y >= 0.0f && xy.y <= 7.0f);
	}
	
	+(BOOL) isJumpFrom:(CGPoint)fromXY to:(CGPoint)toXY
	{
		return (fabsf(toXY.x - fromXY.x) > 1.0f);
	}
	
	+(int) directionFromXY:(CGPoint)fromXY to:(CGPoint)toXY
	{
		return (toXY.x > fromXY.x
			? (toXY.y < fromXY.y ? 1 : 0) // ne / se
			: (toXY.y < fromXY.y ? 2 : 3)); // nw / sw
	}

#pragma mark -
#pragma mark ccTouch methods

	-(void) registerWithTouchDispatcher
	{
		// add ourselves as a touch delegate so we can receive touch messages
		// we have a monopoly on touches, so priority is meaningless
		// swallowsTouches means that we get the touch event, no one else
		[[[CCDirector sharedDirector] touchDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	}

	-(BOOL) ccTouchBegan:(UITouch*)touch withEvent:(UIEvent*)event
	{
		BOOL ret = NO;
		
		// only allow piece pickup if not switching teams
		if( ![self isSwapping] /*|| kAllowCheating*/ )
		{
			CGPoint touchPoint = [touch locationInGL];

			for(CheckerPiece* checkerPiece in checkerPieces)
			{
				// did we touch this piece?
				if(checkerPiece.team == currentTeam
				&& [checkerPiece isAlive]
				&& [checkerPiece containsTouch:touchPoint])
				{
					// start moving this piece
					movingPiece = checkerPiece;
					[movingPiece touch];
					[movingPiece hoverAt:touchPoint];
					ret = YES;
					break;
				}
			}
		}
	
		return ret;
	}
	
	-(void) ccTouchMoved:(UITouch*)touch withEvent:(UIEvent*)event
	{
		if( movingPiece != nil )
		{
			// keep on moving the monster
			[movingPiece hoverAt:[touch locationInGL]];
		}
	}
	
	-(void) ccTouchEnded:(UITouch*)touch withEvent:(UIEvent*)event
	{
		if( movingPiece != nil )
		{
			// switch teams
			CGPoint oldXY = movingPiece.currentXY;
			if( [movingPiece moveTo:[touch locationInGL]] )
			{
				//KITLog(@"is jump? %@", ([CheckerBoard isJumpFrom:oldXY to:movingPiece.currentXY] ? @"yup" : @"nope"));
				
				// wait a second, then swap teams
				CCAction* action = [CCSequence actions:
					[CCDelayTime actionWithDuration:([CheckerBoard isJumpFrom:oldXY to:movingPiece.currentXY] ? 1.5f : 0.3f)],
					[CCCallFunc actionWithTarget:self selector:@selector(swapTeams)],
					nil];
				action.tag = kActionSwap;
				[self runAction:action];
			}

			movingPiece = nil;
		}
	}

@end
