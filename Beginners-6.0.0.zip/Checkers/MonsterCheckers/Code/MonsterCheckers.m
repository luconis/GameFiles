//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "MonsterCheckers.h"

@implementation MonsterCheckers

	-(void) startApp
	{
		// setup our file suffixes for high-res artwork
		CCFileUtils* fileUtils = [CCFileUtils sharedFileUtils];
		[fileUtils setiPhoneRetinaDisplaySuffix:@"-hd"];
		[fileUtils setiPadSuffix:@"-hd"];
		[fileUtils setiPadRetinaDisplaySuffix:@"-hdr"];
	
		// add these sprite frames
		[[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"Effects.plist"];
		
		// create the first scene
		CCScene* scene = [[CCScene alloc] initWithChildClass:[CheckerBoard class]];
		scene.tag = kSceneCheckerBoard;
		[KITApp runScene:scene];
		[scene release];
	}

	-(void) stopApp
	{
	}

	-(void) pauseApp
	{
	}

	-(void) resumeApp
	{
	}

	-(void) foregroundApp
	{
	}
	
	-(void) backgroundApp
	{
	}

@end
