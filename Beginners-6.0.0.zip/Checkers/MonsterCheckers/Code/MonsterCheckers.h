//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#define KITAppSubclassName @"MonsterCheckers"

// add the iPhone Game Kit
#import "iPhoneGameKit.h"

// add Monster Checkers specific code
#import "TouchableNode.h"
#import "CheckerPiece.h"
#import "CheckerBoard.h"

// whether or not to draw rectangles around touchables nodes (aka checker pieces)
#define kDrawRectanglesAroundTouchableNodes 0

// scenes
enum
{
	kSceneCheckerBoard = 1,
};

// teams
enum 
{
	kTeamOne = 0,
	kTeamTwo
};

// animation actions
enum
{
	kActionWiggle = 1,
	kActionHover,
	kActionTouch,
	kActionAttack,
	kActionDie,
	kActionSwap,
};

///
/// The main app class
///
@interface MonsterCheckers : KITApp
@end

