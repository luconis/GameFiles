//
//  See the file 'LICENSE.iPhoneGameKit' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "TouchLayer.h"

@implementation TouchLayer

	-(id) init
	{
		self = [super init];
		if( self != nil )
		{
			// load the map
			map = [[CCTMXTiledMap alloc] initWithTMXFile:@"level1.tmx"];
			[self addChild:map];
			
			// save extents
			CGSize iSize = [[CCDirector sharedDirector] winSize];
			mapMax = CGPointZero;
			mapMin = ccp(-map.mapSize.width * map.tileSize.width,
				-map.mapSize.height * map.tileSize.height);
			mapMin = ccpAdd(mapMin, ccpFromSize(iSize));
			
			// offset layers
			for(CCTMXLayer* layer in map.children)
			{
				if([layer isKindOfClass:[CCTMXLayer class]])
				{
					CGPoint offset = ccp( [[layer propertyNamed:@"xoffset"] intValue],
						[[layer propertyNamed:@"yoffset"] intValue] );
					if(offset.x || offset.y)
						layer.position = ccpAdd(layer.position, offset);
				}
			}
			
			// enable touches so we can drag
			self.isTouchEnabled = YES;
		}
		return self;
	}
	
	-(void) dealloc
	{
		// unset this so we unregister with the touch dispatcher
		self.isTouchEnabled = NO;
		
		// release our map so that it gets dealloced
		[map release];
		
		// always call [super dealloc]
		[super dealloc];
	}

	-(CGPoint) touchToPoint:(UITouch*)touch
	{
		// convert the touch object to a position in our cocos2d space
		return [[CCDirector sharedDirector] convertToGL:[touch locationInView:[touch view]]];
	}
	
	-(void) setMapPosition:(CGPoint)touchPosition
	{
		// set the new position
		map.position = ccpAdd(touchPosition, touchOffset);
		map.position = ccpClamp(map.position, mapMin, mapMax);
	}
	
	-(BOOL) ccTouchBegan:(UITouch*)touch withEvent:(UIEvent*)event
	{
		// calculate offset of touch point
		touchOffset = ccpSub(map.position, [self touchToPoint:touch]);
		
		// claim the touch
		return YES;
	}
	
	-(void) ccTouchMoved:(UITouch*)touch withEvent:(UIEvent*)event
	{
		[self setMapPosition:[self touchToPoint:touch]];
	}
	
	-(void) ccTouchEnded:(UITouch*)touch withEvent:(UIEvent*)event
	{
		[self setMapPosition:[self touchToPoint:touch]];
	}

	-(void) registerWithTouchDispatcher
	{
		// we must implement this method so that we start to receive ccTouch messages
		[[[CCDirector sharedDirector] touchDispatcher] addTargetedDelegate:self
			priority:(kCCMenuHandlerPriority - 2) swallowsTouches:YES];
	}
	
@end
