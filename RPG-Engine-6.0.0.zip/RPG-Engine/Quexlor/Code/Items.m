//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"


@implementation Experience

	-(void) onParentEstablished
	{
		[super onParentEstablished];

		self.contentSize = [[self getLevel] tileSize];
	}
	
	-(void) addEffects:(RPGLevel*)level
	{
		[super addEffects:level];
		
		// create our effect
		[self addGlowEffect:level opacity:196 minScale:self.scale
			maxScale:(self.scale * 1.38f) period:(0.5f + (CCRANDOM_0_1() * 0.5f))];
		[[effects objectForKey:kEffectKeyGlow] setAnchorPoint:ccp(0.5f, 0.3f)];
	}

	-(void) onPickup
	{
		[super onPickup];

		// stop moving and flash
		[RPGHudLayer stopJoypad];
		[[self getHudLayer] animateInfo:YES];
	}
	
@end

@implementation LifeForce

	-(void) addEffects:(RPGLevel*)level
	{
		[super addEffects:level];
		
		[self addGlowEffect:level opacity:64 minScale:0.75f maxScale:1.0f period:0.8f];
	}

@end

@implementation Key
@end

@implementation Bone

	-(void) setGlobalIdFrom:(NSString*)mapFilename leafIndex:(int)leafIndex
	{
		// do not save this item
		globalId = nil;
	}

	-(void) onParentEstablished
	{
		[super onParentEstablished];
		
		// rotate the bone uniquely
		sprite.rotation = (CCRANDOM_0_1() * 360);
	}

@end



@implementation Axes

	-(void) addEffects:(RPGLevel*)level
	{
		[super addEffects:level];
		
		[self addGlowEffect:level opacity:64 minScale:0.5f maxScale:0.69f period:0.8f + (CCRANDOM_0_1() * 0.2f)];
	}

@end

@implementation Bracer

	-(void) addEffects:(RPGLevel*)level
	{
		[super addEffects:level];
		
		[self addGlowEffect:level opacity:64 minScale:0.5f maxScale:0.69f period:0.8f + (CCRANDOM_0_1() * 0.2f)];
	}

@end



@implementation Flames
	
	-(void) steppedOnBy:(RPGLevelObject*)levelObject
	{
	}

	-(void) addEffects:(RPGLevel*)level
	{
		[super addEffects:level];
		
		lifeTimer = [self floatAttributeForKey:kAttributeLife];
		
		// give it a glowing effect
		[self addGlowEffect:level opacity:200 minScale:self.scale maxScale:(self.scale * 1.2f) period:0.5f];
		
		// set up cocos2d properties
		id effect = [effects objectForKey:kEffectKeyGlow];
		[effect setAnchorPoint:ccp(0.5f, 0.4f)];
		[effect setRotation:(-10 + (int)(CCRANDOM_0_1() * 20))];
	}
	
	-(void) update:(ccTime)delta
	{
		// run the lifetime
		if( lifeTimer > 0.0f )
		{
			lifeTimer -= delta;
			if( lifeTimer < 1.0f )
			{
				RPGEffectSprite* effect = [effects objectForKey:kEffectKeyGlow];
				effect.opacity = (int)(200 * lifeTimer);
				effect.scale = lifeTimer;
			}
			if( lifeTimer <= 0.0f )
				[self removeFromLevel];
		}

		// burn the player
		timer -= delta;
		if( timer < 0.0f && [self canPickup] )
		{
			// burn player
			[profile playSound:kSoundKeyPickUp];
			[[self getPlayer] changeLife:-[self floatAttributeForKey:kAttributeStrength] quiet:NO];
			timer = 1.0f;
		}
	}
	
@end



@implementation Food
@end

@implementation Meat
@end

@implementation Fish
@end

@implementation Grapes
@end

@implementation Bread
@end

@implementation Grain
@end

@implementation Flour
@end

@implementation Mushroom
@end

@implementation BadMushroom
@end



@implementation Chest

	-(BOOL) isSolid
	{
		return YES;
	}

	-(void) setProperties:(NSDictionary*)props
	{
		[super setProperties:props];

		sprite.anchorPoint = ccp(0.5f, 0.6f);
		
		if( [self intAttributeForKey:kAttributeLife] > 0 )
		{
			// get item to throw in the air
			id item = [self attributeForKey:kAttributeItem];
			if( [item isKindOfClass:[NSArray class]] )
				item = [item randomObject];
			else if( ![item isKindOfClass:[NSString class]] )
				item = @"Bone";
			[self setAttributeForKey:kAttributeItem value:item];
			
			// get the number of items to throw in the air
			int itemCount = [self intAttributeForKey:kAttributeItemCount];
			if( itemCount <= 0 )
			{
				itemCount = ([item isEqualToString:@"Bone"] ? (CCRANDOM_0_1() * 10.0f) :
					(CCRANDOM_0_1() < 0.05f ? 3 : (CCRANDOM_0_1() < 0.2f ? 2 : 1)));
			}
			[self setIntAttributeForKey:kAttributeItemCount value:itemCount];
		}
		
		// already opened
		else
		{
			CCAnimation* anim = [profile animationForKey:kAnimationKeyDefault];
			[sprite setDisplayFrame:[[anim.frames objectAtIndex:([anim.frames count] - 1)] spriteFrame]];
		}
	}
	
	-(void) onParentEstablished
	{
		[super onParentEstablished];
		
		// position in middle of tile
		[self snapToTile:[self getLevel]];
	}
	
	-(BOOL) emitItem
	{
		if( [self intAttributeForKey:kAttributeItemCount] > 0 )
		{
			NSString* classString = [NSString capitalize:[self attributeForKey:kAttributeItem]];
			Class class = NSClassFromString(classString);
			RPGLevelObject* levelObject = [[self getLevel] createObject:class
				position:self.position
				probability:1.0f
				flip:YES];
			if( levelObject != nil )
			{
				[self addIntToAttributeForKey:kAttributeItemCount value:-1];
				return YES;
			}
		}
		return NO;
	}

	-(BOOL) canBeAttackedBy:(RPGLevelObject*)levelObject ranged:(BOOL)ranged
	{
		return (ranged == NO && [self intAttributeForKey:kAttributeLife] > 0);
	}
	
	-(BOOL) attackedBy:(RPGLevelObject*)levelObject
	{
		// open the chest
		if( [self intAttributeForKey:kAttributeLife] > 0 )
		{
			[profile playSound:kSoundKeyHit];
			[sprite animate:[profile animationForKey:kAnimationKeyDefault] tag:0 repeat:NO restore:NO];

			// create action array to emit items
			int emitCount = [self intAttributeForKey:kAttributeItemCount] * 2; // times two in case some cannot be flipped into place
			NSMutableArray* actions = [[NSMutableArray alloc] initWithCapacity:emitCount * 2];
			for( int i = 0; i < emitCount; i++ )
			{
				[actions addObject:[CCDelayTime actionWithDuration:(0.5f + (CCRANDOM_0_1() * 0.5f))]];
				[actions addObject:[CCCallFunc actionWithTarget:self selector:@selector(emitItem)]];
			}
			
			// run the emit items sequence
			[self runAction:[CCSequence actionWithArray:actions]];
			[actions release];

			[self setIntAttributeForKey:kAttributeLife value:0];
		}
		return YES;
	}

@end

@implementation WeakRock
	
	-(BOOL) isSolid
	{
		return ([self intAttributeForKey:kAttributeLife] > 0);
	}
	
	-(BOOL) canBeAttackedBy:(RPGLevelObject*)levelObject ranged:(BOOL)ranged
	{
		return (ranged == NO);
	}
	
	-(void) setSpriteFrame:(int)life
	{
		// set the appropriate sprite frame
		int displayFrame = clampf(4.0f - life, 0.0f, 4.0f);
		[sprite setDisplayFrame:[profile spriteFrameForKey:kSpriteKeyDefault index:displayFrame]];
		if( life <= 0 )
			[self setLowestZ];
	}

	-(void) onParentEstablished
	{
		[super onParentEstablished];
		
		// position in middle of tile
		[self snapToTile:[self getLevel]];
		
		[self setSpriteFrame:[self intAttributeForKey:kAttributeLife]];
	}
	
	-(BOOL) attackedBy:(RPGLevelObject*)levelObject
	{
		// if the rock is still solid...
		if( [self isSolid] )
		{
			// ...and the player has the bracer
			if( [levelObject hasAbility:kAbilityKeyBracer] )
			{
				int life = [self intAttributeForKey:kAttributeLife];
				life--;
				if( life <= 0 )
				{
					[self setLowestZ];
					life = 0;
				}
				[self setIntAttributeForKey:kAttributeLife value:life];
				[self setSpriteFrame:life];
				
				// always play rock noise
				[profile playSound:kSoundKeyHit];
				
				// animate
				if(life <= 0)
					[self addAuraEffect:[self getLevel] opacity:64 minScale:1.0f maxScale:1.1f period:2.0f];
				
				return YES;
			}
		
			// cannot hit yet
			else
				[profile playSound:kSoundKeyMiss];
		}
		return NO;
	}

@end

@implementation RunePillar

	-(BOOL) isSolid
	{
		return YES;
	}

	-(BOOL) canBeAttackedBy:(RPGLevelObject*)levelObject ranged:(BOOL)ranged
	{
		return (ranged == NO);
	}
	
	-(void) onParentEstablished
	{
		[super onParentEstablished];
		
		[self snapToTile:[self getLevel]];

		sprite.anchorPoint = ccp(0.5f, 0.1f);
	}

	-(BOOL) attackedBy:(RPGLevelObject*)levelObject
	{
		[profile playSound:kSoundKeyMiss];
		
		if( [levelObject hasAbility:kAbilityKeyRunes] )
		{
			[profile playSound:kSoundKeyHit];
			[[self getLevel] createObject:[Dust class] position:self.position probability:1.0f flip:NO];
			[self removeFromLevel];
		}
		
		return YES;
	}

@end


@implementation Switch

	-(BOOL) isSolid
	{
		return YES;
	}

	-(BOOL) canBeAttackedBy:(RPGLevelObject*)levelObject ranged:(BOOL)ranged
	{
		return (ranged == NO);
	}
	
	-(BOOL) attackedBy:(RPGLevelObject*)levelObject
	{
		int hitPoints = [self intAttributeForKey:kAttributeLife];
		if( hitPoints > 0 )
		{
			// animate
			[sprite runAction:[CCAnimate actionWithAnimation:[profile animationForKey:kAnimationKeyDefault]]];
			[profile playSound:kSoundKeyHit distanceSQ:[self distanceSQ:[[self getPlayer] position]]];
			
			// run the switch
			[[self getLevel] decrementCounter:[self attributeForKey:kAttributeCounterKey]];
			[self setIntAttributeForKey:kAttributeLife value:(hitPoints-1)];
			
			return YES;
		}
		
		return NO;
	}

@end

@implementation Door
	
	-(BOOL) isSolid
	{
		return ([self intAttributeForKey:kAttributeOpen] == 0 || [sprite numberOfRunningActions] > 0);
	}
	
	-(BOOL) canBeAttackedBy:(RPGLevelObject*)levelObject ranged:(BOOL)ranged
	{
		return (ranged == NO && [self isSolid]);
	}
	
	-(void) onParentEstablished
	{
		[self snapToTile:[self getLevel]];
		
		sprite.anchorPoint = ccp(0.5f, 0.3f);
		
		// open to start with?
		if( [self intAttributeForKey:kAttributeOpen] > 0 )
		{
			[self setIntAttributeForKey:kAttributeCount value:0];
			CCAnimation* anim = [profile animationForKey:kAnimationKeyDefault];
			[sprite setDisplayFrame:[[anim.frames lastObject] spriteFrame]];
		}
		// closed
		else
		{
			// must have at least a count of 1
			int count = [self intAttributeForKey:kAttributeCount];
			if( count <= 0 )
				[self setIntAttributeForKey:kAttributeCount value:1];
		}
	}
	
	-(void) open:(BOOL)open
	{
		CCAnimation* anim = [profile animationForKey:kAnimationKeyDefault];
		CCActionInterval* action = [CCAnimate actionWithAnimation:anim];

		[sprite runAction:[CCSequence actions:
			(open ? action : [action reverse]),
			[CCCallFunc actionWithTarget:self selector:@selector(onOpenFinished)],
			nil]];

		[self setZ];
	}
	
	-(void) onOpenFinished
	{
		// play sound
		[profile playSoundSolo:kSoundKeyOpen];

		if( [self intAttributeForKey:kAttributeOpen] )
		{
			[self setLowestZ];
			
			// leave some dust
			[[self getLevel] createObject:[Dust class] position:self.position probability:1.0f flip:NO];
		}		
	}
	
	-(void) onCounterDecremented:(int)currentCount
	{
		int isOpen = [self intAttributeForKey:kAttributeOpen];
		int newOpen = (currentCount == 0 ? 1 : 0);
		if( isOpen != newOpen )
		{
			[self setIntAttributeForKey:kAttributeOpen value:newOpen];
			[self open:newOpen];
		}
	}
	
	-(BOOL) attackedBy:(RPGLevelObject*)levelObject
	{
		// use the door
		if( [levelObject isKindOfClass:[RPGPlayer class]] )
		{
			RPGPlayer* player = (RPGPlayer*)levelObject;
			int keys = [player intAttributeForKey:kAttributeKeys];
			NSString* counterKey = [self attributeForKey:kAttributeCounterKey];
			if( [self isSolid] && keys > 0 && ![counterKey length] )
			{
				// open the door and use a key
				[profile playSound:kSoundKeyHit];
				[self open:YES];
				[self setIntAttributeForKey:kAttributeOpen value:1];
				[player setIntAttributeForKey:kAttributeKeys value:(keys - 1)];
				return YES;
			}
			else
				[profile playSound:kSoundKeyMiss];
		}
		
		return NO;
	}
	
	-(void) steppedOnBy:(RPGLevelObject*)levelObject
	{
	}
	
@end


@implementation Teleport

	-(void) onParentEstablished
	{
		[super onParentEstablished];
		
		sprite.anchorPoint = ccp(0.5f, 0.75f);

		justTeleported = NO;
		
		// convert legacy attributes
		NSString* linkWith = [self attributeForKey:@"linkWith"];
		if( [linkWith length] > 0 )
		{
			[self setAttributeForKey:kAttributeFrom value:linkWith];
			[self setAttributeForKey:kAttributeTo value:linkWith];
		}
	}
	
	-(void) teleportTo
	{
		[profile playSound:kSoundKeyPickUp];
		[self getPlayer].position = ccp(self.position.x, self.position.y - 5.0f);
		[[self getPlayer] startSeeking:CGPointZero];
		justTeleported = YES;
	}
	
	-(void) steppedOnBy:(RPGLevelObject*)levelObject
	{
	}
	
	-(void) update:(ccTime)delta
	{
		if( [self canPickup] )
		{
			NSString* to = [self attributeForKey:kAttributeTo];
			if(!justTeleported && [sprite numberOfRunningActions] < 1 && [to length] > 0)
			{
				Teleport* teleport = (Teleport*)[[self getLevel] objectWithClass:[Teleport class] forObject:self attribute:kAttributeFrom value:to];
				if( teleport != nil )
				{
					// warp to this teleport
					id animAction = [CCAnimate actionWithAnimation:[profile animationForKey:kAnimationKeyDefault]];
					[sprite runAction:[CCSequence actions:
						animAction,
						[CCCallFunc actionWithTarget:teleport selector:@selector(teleportTo)],
						[animAction reverse],
						[CCCallFunc actionWithTarget:self selector:@selector(resetSprite)],
						nil]];
				}
			}
		}
		
		// no longer standing on teleport
		else if( justTeleported )
		{
			justTeleported = NO;
		}
	}
	
	-(void) resetSprite
	{
		CCAnimation* anim = [profile animationForKey:@"animation"];
		[sprite setDisplayFrame:[[anim.frames objectAtIndex:0] spriteFrame]];
	}
	
@end

@implementation Warp
@end

@implementation Ambience
@end
