//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

@interface AboutMenuLayer : CCLayer <UIAlertViewDelegate>
	{
		CCMenuItemImage* closeBtn,*eraseBtn;
		CCLabelBMFont* creditsTxt;
		NSString* credits;
		UIAlertView* alert;
	}
@end
