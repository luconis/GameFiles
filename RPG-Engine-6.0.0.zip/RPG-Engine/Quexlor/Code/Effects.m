//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

@implementation Effect

	// don't save effects
	-(void) setGlobalIdFrom:(NSString*)mapFilename leafIndex:(int)leafIndex
	{
		globalId = nil;
	}

	// remove the Effect if no more running actions
	-(void) update:(ccTime)delta
	{
		timer -= delta;
		if( timer <= 0.0f )
		{
			// count running actions
			int numberOfRunningActions = [self numberOfRunningActions];
			for( id effect in [effects allValues] )
				numberOfRunningActions += [effect numberOfRunningActions];
			
			// remove if no more effects running
			if( numberOfRunningActions == 0 )
				[self removeFromLevel];
			
			// otherwise test again in a little bit
			timer = 0.33f;
		}
	}

@end


@implementation Dust
	
	-(void) addEffects:(RPGLevel*)level
	{
		// create our effect
		CCAnimation* anim = [profile animationForKey:kAnimationKeyDefault];
		RPGEffectSprite* effect = [[RPGEffectSprite alloc] initWithSpriteFrame:[[anim.frames objectAtIndex:0] spriteFrame]];
		effect.opacity = 96;
		effect.scale = self.scale + CCRANDOM_0_1();
		
		// flip?
		if( CCRANDOM_0_1() < 0.5f )
			effect.flipX = YES;
		if( CCRANDOM_0_1() < 0.5f )
			effect.flipY = YES;
		
		[effect runAction:[CCSpawn actions:
			[CCScaleBy actionWithDuration:4.0f scale:(self.scale + 1.0f)],
			[CCAnimate actionWithAnimation:anim],
			[CCFadeTo actionWithDuration:9.0f opacity:0],
			nil]];
		[self addEffect:effect withKey:kEffectKeyDefault toLevel:level];
		[effect release];
		KITLog(@"started dust effect");
	}
	
@end


@implementation RPGLevelObject (Effects)

	-(void) addGlowEffect:(RPGLevel*)level opacity:(int)opacity minScale:(float)minScale maxScale:(float)maxScale period:(float)period
	{
		CCAnimation* anim = [profile animationForKey:kAnimationKeyDefault];
		if( anim != nil )
		{
			RPGEffectSprite* effect = [[RPGEffectSprite alloc] initWithSpriteFrame:[[anim.frames objectAtIndex:0] spriteFrame]];
			effect.position = self.position;
			effect.opacity = opacity;
			effect.scale = minScale;
			[effect runAction:[CCRepeatForever actionWithAction:
				[CCSequence actions:
					[CCSpawn actions:
						[CCFlipX actionWithFlipX:NO],
						[CCScaleTo actionWithDuration:period scale:maxScale],
						[CCAnimate actionWithAnimation:anim], // apply duration = period
						nil],
					[CCSpawn actions:
						[CCFlipX actionWithFlipX:YES],
						[CCScaleTo actionWithDuration:period scale:minScale],
						[CCAnimate actionWithAnimation:anim], // apply duration = period
						nil],
					nil]]];
			[self addEffect:effect withKey:kEffectKeyGlow toLevel:level];
			[effect release];
		}
	}
	
	-(void) addAuraEffect:(RPGLevel*)level opacity:(int)opacity minScale:(float)minScale maxScale:(float)maxScale period:(float)period
	{
		CCAnimation* anim = [profile animationForKey:kEffectKeyAura];
		if( anim != nil )
		{
			RPGEffectSprite* effect = [[RPGEffectSprite alloc] initWithSpriteFrame:[[anim.frames objectAtIndex:0] spriteFrame]];
			effect.position = self.position;
			effect.opacity = 0;
			effect.scale = minScale;
			[effect runAction:[CCSequence actions:
				[CCSpawn actions:
					[CCFadeTo actionWithDuration:(period / 2.0f) opacity:opacity],
					[CCAnimate actionWithAnimation:anim], // apply duration = (period / 2.0f)
					nil],
				[CCSpawn actions:
					[CCFadeTo actionWithDuration:(period / 2.0f) opacity:0],
					[CCScaleTo actionWithDuration:(period / 2.0f) scale:maxScale],
					[CCAnimate actionWithAnimation:anim], // apply duration = (period / 2.0f)
					nil],
				[CCDelayTime actionWithDuration:(period + 0.5f)],
				[CCCallFunc actionWithTarget:effect selector:@selector(removeFromParent)],
				nil]];
			[level addEffectSprite:effect];
			// this is a temporary effect which removes itself (do not add it to the effects array)
			[effect release];
		}
	} 

@end
