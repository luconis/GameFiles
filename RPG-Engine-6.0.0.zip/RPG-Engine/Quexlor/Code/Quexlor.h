//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#define KITAppSubclassName @"Quexlor"

// include the RPG engine
#import "RPGEngine.h"

// include the classes for our game
#import "Player.h"
#import "Friends.h"
#import "Boss.h"
#import "Enemies.h"
#import "Projectiles.h"
#import "Items.h"
#import "Effects.h"
#import "MainMenu.h"
#import "CharacterMenu.h"
#import "VictoryMenu.h"
#import "AboutMenu.h"

// constants
#define kLifePerLifeforce 10
#define kTotalSecretsToDiscover 33
#define kDefaultLifeforce 50

// settings
#define kSettingTimesBeatenGame @"timesBeatenGame"

// attributes
#define kAttributeExperience @"experience"
#define kAttributeUsableExperience @"usableExperience"
#define kAttributeBones @"bones"
#define kAttributeKeys @"keys"
#define kAttributeRedKeys @"redKeys"

// abilities
#define kAbilityKeySword @"sword"
#define kAbilityKeyBracer @"bracer"
#define kAbilityKeyRunes @"runes"

// effects
#define kEffectKeyDefault @"effect"
#define kEffectKeyGlow @"effectGlow"
#define kEffectKeyClock @"effectClock"
#define kEffectKeyAura @"effectAura"
#define kEffectKeySmoke @"effectSmoke"

// sprite keys
#define kSpriteKeyEffect @"effect"

// sound keys
#define kSoundKeyHit @"hit"
#define kSoundKeyMiss @"miss"
#define kSoundKeyLevelUp @"levelUp"
#define kSoundKeyCounter @"counter"
#define kSoundKeyOpen @"open"
#define kSoundKeyAttack @"attack"

///
/// The main app class
///

@interface Quexlor : KITApp
@end

