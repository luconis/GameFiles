//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

///
/// An RPGLevelObject which simply animates an effect
///
@interface Effect : RPGLevelObject
@end

@interface Dust : Effect
@end

@interface RPGLevelObject
(Effects)
	-(void) addGlowEffect:(RPGLevel*)level opacity:(int)opacity minScale:(float)minScale maxScale:(float)maxScale period:(float)period;
	-(void) addAuraEffect:(RPGLevel*)level opacity:(int)opacity minScale:(float)minScale maxScale:(float)maxScale period:(float)period;
@end

