//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

#define kAlertViewReset 1

@interface AboutMenuLayer () // private methods
	-(void) autoShowEraseButton;
@end

@implementation AboutMenuLayer

	-(id) init
	{
		self = [super init];
		if(self != nil)
		{
			CGSize iSize = [KITApp winSize];
			alert = nil;
		
			// scale up for ipad3
			if( [KITApp isDoubleHD] )
				self.scale = 2.0f;
			
			// load sound effects for 
			[[KITSound sharedSound] loadSound:@"unsheath.caf"];
			[[KITSound sharedSound] loadSound:@"experience.caf"];

			// add background
			CCSprite* bg = [[CCSprite alloc] initWithFile:@"main-menu.png"];
			bg.position = [KITApp centralize:ccp(0,0)];
			bg.opacity = 96;
			[self addChild:bg z:1];
			[bg release];
			
			// add buttons
			closeBtn = [[CCMenuItemImage alloc]
				initWithNormalImage:@"close-btn-up.png"
				selectedImage:@"close-btn-down.png"
				disabledImage:nil target:self selector:@selector(closeBtnCallback:)];
			eraseBtn = [[CCMenuItemImage alloc]
				initWithNormalImage:@"recycle-btn-up.png"
				selectedImage:@"recycle-btn-down.png"
				disabledImage:nil target:self selector:@selector(eraseBtnCallback:)];
			CCMenu* menu = [CCMenu menuWithItems:closeBtn, eraseBtn, nil];
			menu.position = CGPointZero;
			closeBtn.position = ccp(iSize.width - [KITApp scale:30.0f],
				iSize.height - [KITApp scale:30.0f]);
			eraseBtn.position = ccp(iSize.width - [KITApp scale:30.0f],
				[KITApp scale:30.0f]);
			[self addChild:menu z:3];

			// load credits
			float creditsTime = 55.0f;
			float creditsDivisor = 4.0f;
			NSError* error = nil;
			NSString* creditsFmt = [[NSString alloc] initWithContentsOfFile:
				[[NSBundle mainBundle] pathForResource:@"credits" ofType:@"txt"] encoding:NSUTF8StringEncoding error:&error];
			
			credits = [[NSString alloc] initWithString:creditsFmt];
			creditsTxt = [[self addLabelBMFont:@"font.fnt" string:credits
				position:[KITApp centralize:ccp(0.0f, 0.0f)] scale:0.5f alignment:kAlignmentLeft z:5] retain];
			creditsTxt.position = ccp([KITApp scale:30.0f], -creditsTxt.height / creditsDivisor );
			creditsTxt.opacity = 0;

			[creditsTxt runAction:[CCSpawn actions:
				[CCFadeIn actionWithDuration:1.0f],
				[CCMoveTo actionWithDuration:creditsTime
					position:ccp(creditsTxt.position.x,
						iSize.height + (creditsTxt.height / creditsDivisor))],
				[CCSequence actions:
					[CCDelayTime actionWithDuration:creditsTime - 1.0f],
					[CCFadeOut actionWithDuration:1.0f],
					nil],
				nil]];
			[creditsFmt release];
			
			[self autoShowEraseButton];
			}
		return self;
	}

	-(void) dealloc
	{
		KITLog(@"AboutMenu dealloc");
		
		// release all stuff
		[credits release];
		[creditsTxt release];
		[alert release];
		[eraseBtn release];
		[closeBtn release];
		[super dealloc];
	}

	-(void) autoShowEraseButton
	{
		eraseBtn.visible = [RPGGameScene canContinue];
	}

	-(void) closeBtnCallback:(id)sender
	{
		[[KITSound sharedSound] playSound:@"unsheath.caf"];
		
		[[CCDirector sharedDirector] popScene];
	}

	-(void) eraseBtnCallback:(id)sender
	{
		[[KITSound sharedSound] playSound:@"unsheath.caf"];
		
		// are they sure?
		[alert release];
		alert = [[UIAlertView alloc] initWithTitle:@"Reset"
			message:@"You want to reset the game and start anew?"
			delegate:self
			cancelButtonTitle:@"Cancel"
			otherButtonTitles:nil
			];
		[alert setTag:kAlertViewReset];
		[alert addButtonWithTitle:@"OK"];
		[alert show];
	}

	-(void) alertView:(UIAlertView*)theAlert didDismissWithButtonIndex:(NSInteger)buttonIndex
	{
		if( [theAlert tag] == kAlertViewReset )
		{
			// they clicked ok
			if( buttonIndex == 1 )
			{
				[KITSettings reset];
			}
			
			[self autoShowEraseButton];
		}
	}

@end
