//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

@implementation MenuLayerWithQuexlor

	-(id) init
	{
		self = [super init];
		if( self != nil)
		{
			quexlor = nil;
			aura = nil;
			clock = nil;
			player = nil;
		}
		return self;
	}

	-(void) dealloc
	{
		// update the player's life
		[player updateLifeBar];
		[player release];

		[quexlor release];
		[aura release];
		[clock release];
		[super dealloc];
	}

	-(void) setPlayer:(Player*)p
	{
		player = p;
		[player retain];
		[self redraw];
	}
	
	-(Player*) getPlayer
	{
		return player;
	}
	
	-(void) redraw
	{	
		// for subclass to implement
	}

	-(void) addQuexlor:(KITProfile*)profile position:(CGPoint)pos
	{
		if( quexlor == nil )
		{
			// add quexlor running
			quexlor = [[CCSprite alloc] initWithSpriteFrameName:@"barbarian-king-running-s0000.png"];
			quexlor.position = pos;
			id anim = [profile animationForKey:@"walk" index:0];
			if( anim != nil )
				[quexlor runAction:[CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:anim]]];
			[self addChild:quexlor z:4];

			// add big aura
			aura = [[CCSprite alloc] initWithSpriteFrameName:@"aura0000.png"];
			aura.position = ccp(quexlor.position.x, quexlor.position.y - 14.0f);
			aura.scale = 2.0f;
			aura.opacity = 64;
			CCAnimation* auraAnim = [[CCAnimation alloc] initWithFormat:@"aura00%02d.png" subString:nil frameCount:16 delay:0.05f];
			[aura runAction:[CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:auraAnim]]];
			[auraAnim release]; // CCAnimate action retains this CCAnimation
			[self addChild:aura z:2];

			// add clock
			clock = [[CCSprite alloc] initWithSpriteFrameName:@"rayclock0000.png"];
			clock.position = ccp(quexlor.position.x, quexlor.position.y - [KITApp scale:30.0f]);
			clock.opacity = 224;
			CCAnimation* clockAnim = [[CCAnimation alloc] initWithFormat:@"rayclock00%02d.png" subString:nil frameCount:16 delay:0.05f];
			[clock runAction:[CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:clockAnim]]];
			[clockAnim release]; // CCAnimate action retains this CCAnimation
			[self addChild:clock z:3];
		}
	}

@end


@implementation CharacterMenuLayer

	+(void) scene:(Player*)player
	{
		// create a generic scene
		CCScene* scene = [[CCScene alloc] init];
		
		// add our layer
		CharacterMenuLayer* layer = [[CharacterMenuLayer alloc] init];
		[layer setPlayer:player];
		[scene addChild:layer z:1];
		[layer release];

		// go to the scene without transitioning because the Level still runs during a fade transition
		// and this allows the player to die while transitioning
		[[CCDirector sharedDirector] pushScene:scene];
		[scene release];
	}

	-(id) init
	{
		self = [super init];
		if(self != nil)
		{
			// load sounds
			[[KITSound sharedSound] loadSound:@"unsheath.caf"];

			// scale up for ipad3
			if( [KITApp isDoubleHD] )
				self.scale = 2.0f;
			
			// add background
			CCSprite* bg = [CCSprite spriteWithFile:@"character-menu.png"];
			bg.position = [KITApp centralize:ccp(0,0)];
			[self addChild:bg z:1];
			
			// add items
			swordIcon = [[CCSprite alloc] initWithSpriteFrameName:@"sword.png"];
			swordIcon.position = [KITApp centralize:ccp(-23, 95)];
			swordIcon.scale = 1.2f;
			[swordIcon setVisible:NO];
			[self addChild:swordIcon z:2];
			axeIcon = [[CCSprite alloc] initWithSpriteFrameName:@"throwing-axe.png"];
			axeIcon.position = [KITApp centralize:ccp(7, 94)];
			[axeIcon setVisible:NO];
			[self addChild:axeIcon z:2];
			bracerIcon = [[CCSprite alloc] initWithSpriteFrameName:@"bracer.png"];
			bracerIcon.position = [KITApp centralize:ccp(37, 95)];
			[bracerIcon setVisible:NO];
			[self addChild:bracerIcon z:2];
			ringIcon = [[CCSprite alloc] initWithSpriteFrameName:@"ring.png"];
			ringIcon.position = [KITApp centralize:ccp(-23, 60)];
			[ringIcon setVisible:NO];
			[self addChild:ringIcon z:2];
			bookIcon = [[CCSprite alloc] initWithSpriteFrameName:@"book.png"];
			bookIcon.position = [KITApp centralize:ccp(7, 60)];
			[bookIcon setVisible:NO];
			[self addChild:bookIcon z:2];
			
			// add buttons
			closeBtn = [[CCMenuItemImage alloc]
				initWithNormalImage:@"close-btn-up.png"
				selectedImage:@"close-btn-down.png"
				disabledImage:nil target:self selector:@selector(closeBtnCallback:)];
			homeBtn = [[CCMenuItemImage alloc]
				initWithNormalImage:@"home-btn-up.png"
				selectedImage:@"home-btn-down.png"
				disabledImage:nil target:self selector:@selector(homeBtnCallback:)];
			dpadBtn = [[CCMenuItemImage alloc]
				initWithNormalImage:@"plus-btn-up.png"
				selectedImage:@"plus-btn-down.png"
				disabledImage:nil target:self selector:@selector(dpadBtnCallback:)];
			strengthBtn = [[CCMenuItemImage alloc]
				initWithNormalImage:@"plus-btn-up.png"
				selectedImage:@"plus-btn-down.png"
				disabledImage:nil target:self selector:@selector(strengthBtnCallback:)];
			dexterityBtn = [[CCMenuItemImage alloc]
				initWithNormalImage:@"plus-btn-up.png"
				selectedImage:@"plus-btn-down.png"
				disabledImage:nil target:self selector:@selector(dexterityBtnCallback:)];
			CCMenu* menu = [CCMenu menuWithItems:closeBtn, homeBtn, dpadBtn, strengthBtn, dexterityBtn, nil];
			menu.position = CGPointZero;
			closeBtn.position = [KITApp centralize:ccp(202, 110)];
			homeBtn.position = [KITApp centralize:ccp(202, -108)];
			dpadBtn.position = [KITApp centralize:ccp(202, -5)];
			strengthBtn.position = [KITApp centralize:ccp(112, -67)];
			dexterityBtn.position = [KITApp centralize:ccp(112, -102)];
			dpadBtn.opacity = 1;
			[self addChild:menu z:3];
			
			// flash close button at first
			if(![[KITSettings get] flashedClose])
			{
				[closeBtn runAction:[CCSequence actions:
					[CCDelayTime actionWithDuration:1.5f],
					[CCBlink actionWithDuration:0.69f blinks:3],
					nil]];
				[[KITSettings get] setFlashedClose:YES];
			}
			
			// add numbers
			bonesTxt = [[self addLabelBMFont:@"font.fnt" string:@"1"
				position:[KITApp centralize:ccp(97, 51)]
				scale:0.55f alignment:kAlignmentLeft z:4] retain];
			keysTxt = [[self addLabelBMFont:@"font.fnt" string:@"0"
				position:[KITApp centralize:ccp(97, 104)]
				scale:0.6f alignment:kAlignmentLeft z:4] retain];
			redKeysTxt = [[self addLabelBMFont:@"font.fnt" string:@"0"
				position:[KITApp centralize:ccp(97, 77)]
				scale:0.6f alignment:kAlignmentLeft z:4] retain];
			experienceTxt = [[self addLabelBMFont:@"font.fnt" string:@"1"
				position:[KITApp centralize:ccp(63, -5)]
				scale:0.6f alignment:kAlignmentLeft z:4] retain];
			strengthTxt = [[self addLabelBMFont:@"font.fnt" string:@"1"
				position:[KITApp centralize:ccp(83, -71)]
				scale:0.6f alignment:kAlignmentRight z:4] retain];
			dexterityTxt = [[self addLabelBMFont:@"font.fnt" string:@"1"
				position:[KITApp centralize:ccp(83, -104)]
				scale:0.6f alignment:kAlignmentRight z:4] retain];
			dpadTxt = [[self addLabelBMFont:@"font.fnt" string:@"off"
				position:[KITApp centralize:ccp(202, -10)]
				scale:0.5f alignment:kAlignmentCenter z:4] retain];
			
			// add glow
			strengthBtnGlow = [[CCSprite alloc] initWithFile:@"plus-btn-glowy.png"];
			dexterityBtnGlow = [[CCSprite alloc] initWithFile:@"plus-btn-glowy.png"];
			strengthBtnGlow.position = strengthBtn.position;
			dexterityBtnGlow.position = dexterityBtn.position;
			[self addChild:strengthBtnGlow z:2];
			[self addChild:dexterityBtnGlow z:2];
		}
		return self;
	}

	-(void) dealloc
	{
		KITLog(@"CharacterMenu dealloc");
		
		// release all stuff
		[dpadTxt release];
		[redKeysTxt release];
		[keysTxt release];
		[bonesTxt release];
		[strengthTxt release];
		[dexterityTxt release];
		[experienceTxt release];
		[dexterityBtnGlow release];
		[strengthBtnGlow release];
		[dexterityBtn release];
		[strengthBtn release];
		[closeBtn release];
		[dpadBtn release];
		[homeBtn release];
		[self eraseLifeforce];
		[bookIcon release];
		[ringIcon release];
		[axeIcon release];
		[swordIcon release];
		[bracerIcon release];
		[super dealloc];
	}

	-(void) eraseLifeforce
	{
		[self removeChild:lifeforceNode cleanup:YES];
	}
	
	-(void) addLifeforceIconsToNode:(CCNode*)node count:(int)lifeforces
	{
		int lifeforcePerLine = 5;
		int numLines = (int)(lifeforces / lifeforcePerLine) + 1;
		float xPosScale = [KITApp scale:(numLines == 1 ? 20.0f : 17.5f)];
		float yPosScale = [KITApp scale:(numLines <= 2 ? 15.0f : 10.0f)];
		float iconScale = (numLines == 1 ? 0.6f : (numLines == 2 ? 0.45f : 0.25f));

		for(int i=0; i < lifeforces; i++)
		{
			int x = (i % lifeforcePerLine);
			int y = (int)(i / lifeforcePerLine);
			CCSprite* icon = [CCSprite spriteWithSpriteFrameName:@"meat.png"];
			icon.position = ccp((x * xPosScale), -(y * yPosScale));
			icon.scale = iconScale;
			[node addChild:icon z:1];
		}
	}

	-(void) drawLifeforce
	{
		lifeforceNode = [[CCNode alloc] init];
		lifeforceNode.position = [KITApp centralize:ccp(65.0f,-27.0f)];
		[self addChild:lifeforceNode z:2];

		[self addLifeforceIconsToNode:lifeforceNode count:[player countLifeforce] + 1];
	}

	-(void) redraw
	{
		// show icons
		//int currentSwordLevel = [player intAttributeForKey:kAttributeSwordLevel];
		//if(currentSwordLevel >= kSwordLevelSword)
			[swordIcon setVisible:YES];
		if( [player hasAbility:kAbilityKeyRangedAttack] )
			[axeIcon setVisible:YES];
		if( [player hasAbility:kAbilityKeyBracer] )
			[bracerIcon setVisible:YES];
		//if(currentSwordLevel >= kSwordLevelStompring)
		//	[ringIcon setVisible:YES];
		//if(currentSwordLevel >= kSwordLevelRunebook)
		//	[bookIcon setVisible:YES];
			
		// show life force
		[self drawLifeforce];
		
		// show increase attribute buttons
		BOOL enabled = ([player intAttributeForKey:kAttributeUsableExperience] > 0);
		[strengthBtn setVisible:enabled];
		[strengthBtn setIsEnabled:enabled];
		[strengthBtnGlow setVisible:enabled];
		[dexterityBtn setVisible:enabled];
		[dexterityBtn setIsEnabled:enabled];
		[dexterityBtnGlow setVisible:enabled];
		[clock setVisible:enabled];
		if( enabled )
		{
			[strengthBtnGlow glow:0.69f];
			[dexterityBtnGlow glow:0.69f];
		}

		// show text
		[bonesTxt setString:[NSString stringWithFormat:@"%u", [player intAttributeForKey:kAttributeBones]]];
		[keysTxt setString:[NSString stringWithFormat:@"%u", [player intAttributeForKey:kAttributeKeys]]];
		[redKeysTxt setString:[NSString stringWithFormat:@"%u", [player intAttributeForKey:kAttributeRedKeys]]];
		[experienceTxt setString:[NSString stringWithFormat:@"%d / %d", [player countSecrets], kTotalSecretsToDiscover]];
		[strengthTxt setString:[NSString stringWithFormat:@"%.0f", [player floatAttributeForKey:kAttributeStrength] * 11.5f]];
		[dexterityTxt setString:[NSString stringWithFormat:@"%.0f", [player floatAttributeForKey:kAttributeDexterity] * 11.5f]];
		[dpadTxt setString:([[KITSettings get] touchMovement] ? @"off" : @"on")];

		// add quexlor
		KITProfile* profile = [KITProfile profileWithName:[player attributeForKey:kAttributeProfileName]];
		[self addQuexlor:profile position:[KITApp centralize:ccp(-80,86)]];
		aura.opacity = 32;
	}

	-(void) closeBtnCallback:(id)sender
	{
		[[KITSound sharedSound] playSound:@"unsheath.caf"];
		
		[[CCDirector sharedDirector] popScene];
	}

	-(void) homeBtnCallback:(id)sender
	{
		[[KITSound sharedSound] playSound:@"unsheath.caf"];
		
		[[player getLevel] saveSettings];
		
		// pop this scene
		[[CCDirector sharedDirector] popScene];

		// fade to the main menu layer
		CCScene* scene = [[CCScene alloc] initWithChildClass:[MainMenuLayer class]];
		[KITApp fadeToScene:scene duration:2.0f];
		[scene release];
	}

	-(void) dpadBtnCallback:(id)sender
	{
		[[KITSound sharedSound] playSound:@"unsheath.caf"];
		
		[[KITSettings get] setTouchMovement:!([[KITSettings get] touchMovement])];
		
		[[player getLevel] saveSettings];
		
		[self redraw];
	}

	-(void) strengthBtnCallback:(id)sender
	{
		[[KITSound sharedSound] playSound:@"unsheath.caf"];
		
		[player addFloatToAttributeForKey:kAttributeStrength value:1.0f];
		[player addIntToAttributeForKey:kAttributeUsableExperience value:-1];
		
		[self redraw];
	}

	-(void) dexterityBtnCallback:(id)sender
	{
		[[KITSound sharedSound] playSound:@"unsheath.caf"];
		
		[player addFloatToAttributeForKey:kAttributeDexterity value:1.0f];
		[player addIntToAttributeForKey:kAttributeUsableExperience value:-1];
		
		[self redraw];
	}

@end
