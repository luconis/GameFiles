//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"


@implementation ThrownAxe

	-(void) addEffects:(RPGLevel*)level
	{
		[super addEffects:level];
		
		RPGEffectSprite* effect = [[RPGEffectSprite alloc] initWithSpriteFrame:[profile spriteFrameForKey:kSpriteKeyEffect]];
		effect.visible = NO;
		effect.scale = 0.8f;
		[effect runAction:[CCRepeatForever actionWithAction:[CCRotateBy actionWithDuration:0.69f angle:360.0f]]];
		[self addEffect:effect withKey:kEffectKeyDefault toLevel:level];
		[effect release];
	}

	-(void) launch
	{
		// show the axe now
		RPGEffectSprite* effect = [effects objectForKey:kEffectKeyDefault];
		effect.visible = YES;
	}
	
	-(void) update:(ccTime)delta
	{
		// use Projectile's update method to move
		[super update:delta];
		
		// fade out the magical axe
		if( lifeTimer > 0.0f && lifeTimer < 1.0f )
		{
			RPGEffectSprite* effect = [effects objectForKey:kEffectKeyDefault];
			effect.opacity = (int)(255 * lifeTimer);
		}
	}

@end



@implementation ShotArrow

	-(void) launch
	{
		// rotate & scale arrow
		float angle = ccpToAngle(vector);
		sprite.rotation = ((-angle + (M_PI / 2.0f)) / M_PI) * 180.0f;
		sprite.scale = 0.8f;
	}

@end

