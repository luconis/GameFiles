//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

@implementation Boss

	-(id) init
	{
		self = [super init];
		if( self != nil )
		{
			// pre-load ambiance
			ambience = nil;
		}
		return self;
	}

	-(void) addEffects:(RPGLevel*)level
	{
		[super addEffects:level];
		
		// load smoke anim
		CCAnimation* anim = [profile animationForKey:kEffectKeySmoke];
		RPGEffectSprite* effect = [[RPGEffectSprite alloc] initWithSpriteFrame:[[anim.frames objectAtIndex:0] spriteFrame]];
		effect.opacity = 0;
		effect.scale = 2.0f;
		effect.offset = ccp(10.0f, 10.0f);
		[self addEffect:effect withKey:kEffectKeySmoke toLevel:level];
		[effect release];
	}

	-(void) onEnter
	{
		[super onEnter];

		// add ambience
		if( ambience == nil )
			[self createAmbience];
	}
	
	-(void) createAmbience
	{
		// for subclasses to override
		[self createAmbience:nil];
	}
	
	-(void) createAmbience:(NSString*)soundName
	{
		if( ambience != nil )
		{
			[ambience removeFromLevel];
		}
		
		if( soundName != nil && [self isAlive] )
		{
			ambience = (RPGAmbience*)[[self getLevel] createObject:[RPGAmbience class] position:self.position probability:1.0f flip:NO];
			[ambience setAttributeForKey:kAttributeAmbienceFilename value:soundName];
			[ambience setFloatAttributeForKey:kAttributeAmbienceRadius value:15.0f];
			[ambience setIntAttributeForKey:kAttributeAmbienceLooping value:1];
		}
	}
	
	-(void) setPosition:(CGPoint)position
	{
		[super setPosition:position];
		[ambience setPosition:position];
	}

	-(void) onDeath
	{
		// smoke effect
		CCAnimation* anim = [profile animationForKey:kEffectKeySmoke];
		RPGEffectSprite* effect = [effects objectForKey:kEffectKeySmoke];
		effect.opacity = 96;
		[effect runAction:[CCSpawn actions:
			[CCScaleBy actionWithDuration:4.0f scale:3.0f],
			[CCAnimate actionWithAnimation:anim],
			[CCFadeTo actionWithDuration:12.0f opacity:0],
			nil]];
		
		if( ambience != nil )
			[ambience stopPlaying];
	}

@end	

