//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

@implementation Quexlor

	-(void) startApp
	{
		// setup our file suffixes for high-res artwork
		CCFileUtils* fileUtils = [CCFileUtils sharedFileUtils];
		[fileUtils setiPhoneRetinaDisplaySuffix:@"-hires"];
		[fileUtils setiPadSuffix:@"-hires"];
		[fileUtils setiPadRetinaDisplaySuffix:@"-hires"];

		// load the game state
		if( ![KITSettings loadSettings:0] )
			[KITSettings reset];

		// now that window is attached, set a 2d projection for better z ordering
		[[CCDirector sharedDirector] setProjection:kCCDirectorProjection2D];

		// load sprite frames & sounds we most likely need
		[[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"items.plist"];
		[[KITSound sharedSound] loadSound:@"item-swoosh.caf"];
		
		// go straight to the game
		[RPGGameScene playGame];
	}

	-(void) stopApp
	{
		[[[Player get] getLevel] saveSettings];
		[KITSettings purge];
	}

	-(void) pauseApp
	{
		// the main App class handles this
	}
	
	-(void) resumeApp
	{
		// stop the hud's old movement
		[RPGHudLayer stopJoypad];
	}
	
	-(void) foregroundApp
	{
		// no need to load the game state because our app was only hibernating
	}

	-(void) backgroundApp
	{
		[[[Player get] getLevel] saveSettings];
	}
	
@end
