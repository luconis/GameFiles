//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

@interface MainMenuLayer () // private methods
	-(void) showLoadingScreen:(SEL)selector;
@end

@implementation MainMenuLayer

	-(id) init
	{
		self = [super init];
		if(self != nil)
		{
			CGSize iSize = [KITApp winSize];
			self.isTouchEnabled = YES;
			startingGame = NO;
			musicId = CD_MUTE;
			musicVolume = 1.0f;

			// scale up for ipad3
			if( [KITApp isDoubleHD] )
				self.scale = 2.0f;
		
			// start loading sound effects
			[[KITSound sharedSound] loadSound:@"unsheath.caf"];
			[[KITSound sharedSound] loadSound:@"harp.caf"];
			[[KITSound sharedSound] loadSound:@"flute.caf"];
			
			// add background
			CCSprite* bg = [[CCSprite alloc] initWithFile:@"main-menu.png"];
			bg.position = [KITApp centralize:ccp(0,0)];
			[self addChild:bg z:1];

			// make sword glow
			CCSprite* swordGlow = [[CCSprite alloc] initWithFile:@"mainmenu-swordglow.png"];
			swordGlow.position = [KITApp centralize:ccp(12, -60)];
			[self addChild:swordGlow z:1];
			[swordGlow runAction:[CCRepeatForever actionWithAction:[CCSequence actions:
				[CCFadeTo actionWithDuration:1.25f opacity:255],
				[CCFadeTo actionWithDuration:1.0f opacity:0],
				nil]]];
			
			// create buttons
			aboutBtn = [[CCMenuItemImage alloc]
				initWithNormalImage:@"info-btn-up.png"
				selectedImage:@"info-btn-down.png"
				disabledImage:nil target:self selector:@selector(aboutCallback:)];
			
			// add the buttons to the menu
			CCMenu* menu = [CCMenu menuWithItems: aboutBtn, nil];
			menu.position = CGPointZero;
			aboutBtn.position = ccp(0.0f + [KITApp scale:30.0f], iSize.height - [KITApp scale:30.0f]);
			[self addChild:menu z:2];

			// add glow to about button
			aboutBtnGlow = [[CCSprite alloc] initWithFile:@"info-btn-glow.png"];
			aboutBtnGlow.position = aboutBtn.position;
			[aboutBtnGlow glow:2.25f];
			[self addChild:aboutBtnGlow z:1];

			// create a loop to check if the ambiance has finished loading
			[self schedule:@selector(soundLoop:) interval:1/15.0f];
		}
		return self;
	}

	-(void) dealloc
	{
		KITLog(@"MainMenu dealloc");
		
		// stop the menu ambiance
		[[KITSound sharedSound] stopSound:musicId];
		[[KITSound sharedSound] unloadSound:@"flute.caf"];
		[self unschedule:@selector(soundLoop:)];
		
		// release items
		[aboutBtn release];
		[aboutBtnGlow release];
		[loadingTxt release];
		[gray release];

		[super dealloc];
	}

	-(void) registerWithTouchDispatcher
	{
		// add ourselves as a touch delegate so we can receive touch messages
		[[[CCDirector sharedDirector] touchDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	}

	-(void) soundLoop:(ccTime)delta
	{
		// if the sound is done loading then we can play
		if( musicId == CD_MUTE && [[KITSound sharedSound] isDoneLoading])
		{
			// play the ambiance
			musicId = [[KITSound sharedSound] playSound:@"flute.caf" volume:1.0f pan:1.0f pitch:1.0f loop:YES group:kSoundGroupSingle];
		}
		
		// if we are loading the game then fade out
		if( musicId != CD_MUTE && startingGame )
		{
			musicVolume -= (delta / 2.0f);
			[[KITSound sharedSound] setVolume:musicId volume:musicVolume];
		}
	}
	
	-(void) showLoadingScreen:(SEL)selector
	{
		// show loading screen
		gray = [[CCLayerColor alloc] initWithColor:ccc4(16, 16, 16, 220)];
		[self addChild:gray z:4];
		
		// show loading text
		loadingTxt = [[self addLabelBMFont:@"font.fnt" string:@"Loading..."
			position:[KITApp centralize:ccp(-71, 0)]
			scale:0.85f alignment:kAlignmentLeft z:5] retain];
		
		// make first letter big
		[[[loadingTxt children] objectAtIndex:0] setScale:1.5f];

		// wait a bit then call selector
		[self runAction:[CCSequence actions:
			[CCDelayTime actionWithDuration:0.01f],
			[CCCallFunc actionWithTarget:self selector:selector],
			nil]];
	}

	-(BOOL) ccTouchBegan:(UITouch*)touch withEvent:(UIEvent*)event
	{
		return YES;
	}
	
	-(void) ccTouchEnded:(UITouch*)touch withEvent:(UIEvent*)event
	{
		// make noise
		[[KITSound sharedSound] playSound:@"harp.caf"];
		startingGame = YES;
		
		// show the loading screen
		[self showLoadingScreen:@selector(playGameCallback)];
	}
	
	-(void) playGameCallback
	{
		[RPGGameScene playGame];
	}
	
	-(void) aboutCallback:(id)sender
	{
		// shiiiing!
		[[KITSound sharedSound] playSound:@"unsheath.caf"];
		
		// push the about scene on the scene stack
		CCScene* scene = [[CCScene alloc] initWithChildClass:[AboutMenuLayer class]];
		[[CCDirector sharedDirector] pushScene:scene];
		[scene release];
	}

@end
