//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

@interface Player () // private methods
	-(void) destroyTile;
	-(RPGLevelObject*) findMeleeAttackee;
	-(void) grow;
	-(BOOL) canSwingSword;
	-(void) throwAxeAt:(RPGLevelObject*)levelObject;
	-(void) levelUp:(float)experienceGained;
@end

@implementation Player

	-(void) setProperties:(NSDictionary*)properties
	{
		[super setProperties:properties];
		
		[self grow];
	}
	
	-(void) addEffects:(RPGLevel*)level
	{
		[super addEffects:level];
		
		// load experience effects
		CCAnimation* anim = [profile animationForKey:kEffectKeyClock];
		RPGEffectSprite* effectClock = [[RPGEffectSprite alloc] initWithSpriteFrame:[[anim.frames objectAtIndex:0] spriteFrame]];
		effectClock.position = ccp(0.0f, -27.0f);
		effectClock.anchorPoint = sprite.anchorPoint;
		[effectClock setVisible:NO];
		[self addEffect:effectClock withKey:kEffectKeyClock toLevel:nil];
		[self addChild:effectClock];
		[effectClock release];

		anim = [profile animationForKey:kEffectKeyAura];
		RPGEffectSprite* effectAura = [[RPGEffectSprite alloc] initWithSpriteFrame:[[anim.frames objectAtIndex:0] spriteFrame]];
		effectAura.opacity = 0;
		effectAura.offset = ccp(0.0f, 7.0f);
		[self addEffect:effectAura withKey:kEffectKeyAura toLevel:level];
		[effectAura release];
	}

	-(void) onEnter
	{
		[super onEnter];
		
		// animate the info button if we have experience to use
		BOOL hasUsableExperience = ([self intAttributeForKey:kAttributeUsableExperience] > 0);
		[[self getHudLayer] animateInfo:hasUsableExperience];
	}
	
	-(void) attack:(RPGLevelObject*)levelObject
	{
		if( [self canSwingSword] )
		{
			// always make noise, show life and stop walking
			[self showLifeBar];
			[self stopMoving];
			
			// find an enemy
			if( levelObject == nil )
				levelObject = [self findMeleeAttackee];

			// melee attack the enemy
			if( levelObject != nil && [self canAttack:levelObject ranged:NO] )
			{
				[super attack:levelObject];
			}

			// launch an axe
			else if( [self hasAbility:kAbilityKeyRangedAttack] )
			{
				[self throwAxeAt:levelObject];
				[super attack:levelObject];
				[self destroyTile];
			}

			// otherwise try to destroy a tile
			else
			{
				[self playSound:kSoundKeyAttack];
				[self destroyTile];
			}
		}
	}
	
	-(BOOL) takeOwnershipOf:(RPGLevelObject*)levelObject
	{
		Class class = [levelObject class];

		// player obtained a Bone
		if( class == [Bone class] )
		{
			[self addIntToAttributeForKey:kAttributeBones value:1];
			[self animateAura:1.0f];
		}
		
		// player obtained a Key
		else if( class == [Key class] )
		{
			[self addIntToAttributeForKey:kAttributeKeys value:1];
			[self animateAura:1.0f];
		}
		
		// player ate some Food
		else if( [levelObject isKindOfClass:[Food class]] )
		{
			float lifeBonus = [levelObject floatAttributeForKey:kAttributeLife];
			[self playSound:(lifeBonus >= 0.0f ? @"eat" : @"eatBad")];
			[self changeLife:lifeBonus quiet:YES];
		}
		
		// player obtained Experience
		else if( class == [Experience class] )
		{
			float experienceGained = [levelObject floatAttributeForKey:kAttributeUsableExperience];
			if( experienceGained < 1 )
				experienceGained = 1;
			[self addFloatToAttributeForKey:kAttributeUsableExperience value:experienceGained];
			[self levelUp:experienceGained];
		}
		
		// player obtained LifeForce
		else if( class == [LifeForce class] )
		{
			float newLife = [levelObject floatAttributeForKey:kAttributeMaxLife];
			if( newLife < kLifePerLifeforce )
				newLife = kLifePerLifeforce;
			newLife += [self floatAttributeForKey:kAttributeMaxLife];

			[self setFloatAttributeForKey:kAttributeMaxLife value:newLife];
			[self playSound:@"lifeforce"];
			[self levelUp:1.0f];
		}
		
		// player obtained Axes
		else if( [levelObject isKindOfClass:[Axes class]] )
		{
			[self enableAbility:kAbilityKeyRangedAttack enabled:YES];

			// animate
			[profile playSound:kSoundKeyLevelUp];
			[self animateClock];
			[self animateAura:2.25f];
		}

		// player obtained the Bracer
		else if( [levelObject isKindOfClass:[Bracer class]] )
		{
			[self enableAbility:kAbilityKeyBracer enabled:YES];

			// animate
			[profile playSound:kSoundKeyLevelUp];
			[self animateClock];
			[self animateAura:2.25f];
		}
		
		else
		{
			KITLog(@"Don't know how to takeOwnershipOf %@", levelObject);
			return NO;
		}
		
		return YES;
	}

	-(void) levelUp:(float)experienceGained
	{
		[self setFloatAttributeForKey:kAttributeLife value:[self floatAttributeForKey:kAttributeMaxLife]];
		[self addIntToAttributeForKey:kAttributeExperience value:experienceGained];
		[self updateLifeBar];
		[self showLifeBar];
		[self animateClock];
		[self animateAuras:2.0f];
		[self grow];
	}

	-(void) beatTheGame
	{
		// save
		int timesBeatenGame = [[[[KITSettings get] dictionary] objectForKey:kSettingTimesBeatenGame] intValue] + 1;
		[[[KITSettings get] dictionary] setValue:[NSNumber numberWithInt:timesBeatenGame] forKey:kSettingTimesBeatenGame];
		[[self getLevel] saveSettings];

		// show victory menu
		Class victoryMenuClass = NSClassFromString(@"VictoryMenuLayer");
		[victoryMenuClass scene:self];
	}
	
	-(int) countLifeforce
	{
		return (([self floatAttributeForKey:kAttributeMaxLife] - kDefaultLifeforce) / kLifePerLifeforce);
	}

	-(int) countSecrets
	{
		return [self intAttributeForKey:kAttributeExperience];
	}

	-(void) animateClock
	{
		RPGEffectSprite* effectClock = [effects objectForKey:kEffectKeyClock];
		CCAnimation* clockAnim = [profile animationForKey:kEffectKeyClock];
		[effectClock runAction:[CCSequence actions:
			[CCShow action],
			[CCAnimate actionWithAnimation:clockAnim],
			[CCAnimate actionWithAnimation:clockAnim],
			[CCHide action],
			nil]];
	}

	-(void) animateAura:(float)scale
	{
		RPGEffectSprite* effectAura = [effects objectForKey:kEffectKeyAura];
		effectAura.scale = scale;
		[effectAura runAction:[CCSequence actions:
			[CCFadeTo actionWithDuration:0.5f opacity:64],
			[CCAnimate actionWithAnimation:[profile animationForKey:kEffectKeyAura]],
			[CCFadeTo actionWithDuration:0.5f opacity:0],
			nil]];
	}

	-(void) animateAuras:(float)scale
	{
		RPGEffectSprite* effectAura = [effects objectForKey:kEffectKeyAura];
		[effectAura runAction:[CCSequence actions:
			[CCSpawn actions:
				[CCScaleTo actionWithDuration:0.2f scale:scale],
				[CCFadeTo actionWithDuration:0.2f opacity:64],
				nil],
			[CCAnimate actionWithAnimation:[profile animationForKey:kEffectKeyAura]], // modify this duration to 0.5f total?
			[CCFadeTo actionWithDuration:0.1f opacity:0],
			[CCSpawn actions:
				[CCAnimate actionWithAnimation:[profile animationForKey:kEffectKeyAura]],
				[CCFadeTo actionWithDuration:0.2f opacity:64],
				[CCScaleTo actionWithDuration:1.5f scale:10.0f],
				nil],
			[CCFadeTo actionWithDuration:0.2f opacity:0],
			nil]];
	}

	-(BOOL) canSwingSword
	{
		// we could also check for [self hasAbility:kAbilityKeySword]
		// but in this game the player has a sword by default
		return ([self isAlive]
			&& ![self isAttacking]
			&& ![self isBeingKnockedBack]
			&& [self getHudLayer].isControlEnabled);
	}

	-(RPGLevelObject*) findMeleeAttackee
	{
		RPGLevelObject* levelObject = [[self getLevel] objectAt:self.position forObject:self isSolid:YES fuzziness:3.0f];
		if( [self canAttack:levelObject ranged:NO] )
			return levelObject;
		return nil;
	}
	
	-(void) throwAxeAt:(RPGLevelObject*)levelObject
	{
		// create axe
		ThrownAxe* axe = (ThrownAxe*)[[self getLevel] createObject:[ThrownAxe class]
			position:[self attackPoint] probability:1.0f flip:NO];

		// play sound
		if( axe != nil )
		{
			[profile playSound:@"rangedAttack"];

			// set vector
			if( levelObject != nil )
				axe.vector = [self vectorTo:levelObject];
			else
				axe.vector = [RPGEngine directionToVector:currentDir];

			// set other properties
			float currentPlayerStrength = [self floatAttributeForKey:kAttributeStrength];
			float currentPlayerDexterity = [self floatAttributeForKey:kAttributeDexterity];
			axe.speed = 210.0f + currentPlayerDexterity;
			axe.damage = 0.5f + clampf(0.125f * currentPlayerStrength, 1.0f, 2.0f);
			axe.delayTimer = 0.1f;
			axe.lifeTimer = (0.15f * currentPlayerStrength);
			axe.targetClass = [RPGEnemy class];
		}
	}

	-(void) destroyTile
	{
		// start animating the swing, when finished try to destroy a tile
		CCAction* action = [CCSequence actions:
			[CCAnimate actionWithAnimation:[profile animationForKey:@"attack" index:currentDir]],
			[CCCallFuncN actionWithTarget:self selector:@selector(destroyTileCallback:)],
			[CCCallFunc actionWithTarget:self selector:@selector(resetSprite)],
			nil];
		action.tag = kActionAttack;
		[sprite runAction:action];
	}
	
	-(void) destroyTileCallback:(id)sender
	{
		// attempt to destroy tile
		[[self getLevel] destroyTile:[self attackPoint]];
	}

	-(void) grow
	{
		float exp = clampf([self floatAttributeForKey:kAttributeExperience], 0.0f, 100.0f);
		self.scale = 1.0f + (exp / 100.0f);
	}

@end
