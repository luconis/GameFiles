//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "RPGEngine.h"


@interface RPGAI ()
	-(BOOL) canUpdate;
	-(BOOL) isFriend;
	-(BOOL) willFlee;
@end

@implementation RPGAI

#pragma mark -
#pragma mark Public Methods

	-(id) init
	{
		self = [super init];
		if(self != nil)
		{
			// start in sleep mood
			[self setMood:kMoodSleep];
			
			// calculate distance that the enemy will wake up for
			wakeDistanceSQ = kAIInitialWakeDistanceSQ;
			playerDistanceSQ = 999999.0f;
		}
		return self;
	}

	-(void) walk
	{
		// move by seeking
		if( seekPos.x != 0.0f && seekPos.y != 0.0f )
		{
			// update seek
			if( seekTime > 1.5f )
			{
				[self startSeeking:CGPointZero];
				lastMove = ccp(3.0f,3.0f);
			}
			
			// move by seeking
			[self moveBySeeking];
		}
		
		// move in current direction
		else
		{
			BOOL canCurrentlyFly = [[self attributeForKey:kAttributeCanFly] boolValue];
			CGPoint v = ((canCurrentlyFly && mood == kMoodSeek) ?
				[self vectorTo:[self getPlayer]] :
				[RPGEngine directionToVector:currentDir]);
			[self moveBy:ccpMult(v, delta)];

			// start seeking
			if( [self didntMoveBy:4.0f] && ![self isKindOfClass:[RPGFriend class]] )
			{
				CGPoint playerPos = [self getPlayer].position;
				[self pointToward:playerPos];
				[self startSeeking:playerPos];
			}
		}
	}

	-(void) setMood:(SEL)newMood
	{
		// set new Mood
		mood = newMood;
		
		// reset the timer so the mood initializes itself
		timer = kTimerUp;
	}

	-(void) chooseMood
	{
		// this is the default chooseMood method
		// override it to implement different enemy personalities
		
		// choose between seeking and sleeping
		[self setMood:([self canWakeup] ? kMoodSeek : kMoodSleep)];
	}

	-(BOOL) canWakeup
	{
		// can wake if player is alive and is close enough
		RPGPlayer* player = [self getPlayer];
		
		// note that player distance is saved for later use
		playerDistanceSQ = [self distanceSQ:player.position];
		
		return ([player isAlive] && playerDistanceSQ < wakeDistanceSQ);
	}

	-(float) sleepTime
	{
		return 0.5f;
	}

#pragma mark -
#pragma mark Moods

	-(void) moodSleep
	{
		// starting sleep mood...
		if(timer == kTimerUp)
		{
			timer = [self sleepTime] + ([self sleepTime] * CCRANDOM_0_1());
		}
		
		// wake up?
		else if(timer <= 0.0f)
		{
			[self chooseMood];
			
			// play wake up noise
			if( mood != kMoodSleep )
				[profile playSound:@"wake"];
		}
	}

	-(void) moodSeek
	{
		// starting seek mood...
		if(timer == kTimerUp)
		{
			timer = 1.0f;
			[self pointToward:[[self getPlayer] position]];
			
			// randomly play seek noise (see wasp)
			if( CCRANDOM_0_1() < 0.2f )
				[profile playSound:@"seek"];
		}
		
		// timer up
		else if(timer <= 0.0f)
		{
			[self chooseMood];
		}
		
		// walk in current direction
		[self walk];
	}

	-(void) moodFlee
	{
		// starting fleeing mood
		if(timer == kTimerUp)
		{
			timer = 3.0f + (3.0f * CCRANDOM_0_1());
			[self pointAwayFrom:[self getPlayer].position];
		}
		
		// try a random direction
		/*if([self didntMoveBy:0.0f] || ![[self getPlayer] isAlive] || CCRANDOM_0_1() < 0.25f)
		{
			if( CCRANDOM_0_1() <= 0.7f )
				[self pointAwayFrom:[self getPlayer].position];
			else
				[self setDirection:(rand() % 8)];
		}
		
		// stop fleeing
		else*/ if(timer <= 0.0f)
			[self chooseMood];
		
		// walk (a little faster while fleeing)
		float origDexterity = [self floatAttributeForKey:kAttributeDexterity];
		[self addFloatToAttributeForKey:kAttributeDexterity value:3.0f];
		[self walk];
		[self setFloatAttributeForKey:kAttributeDexterity value:origDexterity];
	}

	-(void) moodRandom
	{
		// starting random mood...
		if(timer == kTimerUp)
		{
			timer = 1.0f + CCRANDOM_0_1();
			if( CCRANDOM_0_1() < 0.5f )
				[self setDirection:(rand() % 8)];
			
			// stay inside the level (for AI that canFly)
			if( ![[self getLevel] isValidPosition:self.position] )
				[self pointToward:[[self getPlayer] position]];
		}
		
		// timer up
		else if(timer <= 0.0f)
		{
			// stay in random mood
			if( CCRANDOM_0_1() < 0.5f )
				[self setMood:kMoodRandom];
			
			// seek or sleep
			else
				[self chooseMood];
		}
		
		// walk in current direction
		[self walk];
	}

	-(void) moodRangedAttack
	{
		// not for default enemies
		[self setMood:kMoodSeek];
	}

	-(void) moodZombie
	{
		// not for default enemies
		[self setMood:kMoodSeek];
	}

	-(void) moodSpecial
	{
		// not for default enemies
		[self setMood:kMoodSeek];
	}

#pragma mark -
#pragma mark Instance methods

	-(BOOL) canUpdate
	{
		return (([self isAlive] || mood == kMoodZombie) && ![self isBeingKnockedBack]);
	}

	-(void) update:(ccTime)newDelta
	{
		delta = newDelta;

		if( [self canUpdate] )
		{
			// count down the timer
			if( timer != kTimerUp )
				timer -= delta;

			// think and move in the current mood
			[self performSelector:mood];
		}
	}
	
	-(BOOL) attackedBy:(RPGLevelObject*)levelObject
	{
		BOOL ret = [super attackedBy:levelObject];
		if( ret )
		{
			// flee?
			if( [self willFlee] )
				[self setMood:kMoodFlee];
		}
		return ret;
	}
	
	-(BOOL) isFriend
	{
		return [self isKindOfClass:[RPGFriend class]];
	}

	-(BOOL) willFlee
	{
		if( ![self isAlive] )
			return NO;
		
		float currentLife = [self floatAttributeForKey:kAttributeLife];
		float currentMaxLife = [self floatAttributeForKey:kAttributeMaxLife];

		// flee if less than 30% health
		// or flee if a friend that's been hit
		return ((CCRANDOM_0_1() < 0.3f && (currentLife < (currentMaxLife * 0.30f)))
			|| ([self isFriend] && currentLife < currentMaxLife));
	}

	-(void) playSound:(NSString*)key
	{
		// this overrides Character's playSound method to add distance
		[profile playSound:key distanceSQ:playerDistanceSQ];
	}

@end
