//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "RPGEngine.h"

///
/// A subclass of RPGLevelObject that plays an ambience sound file.
/// Attributes are sound (the sound file), radius and looping.
/// Only one Ambience can be playing at a time.
///
@interface RPGAmbience : RPGLevelObject
	{
		ALuint soundId;
		float maxDistanceSQ;
		BOOL stopping;
	}

	/// Stops the ambience
	-(void) stopPlaying;

@end
