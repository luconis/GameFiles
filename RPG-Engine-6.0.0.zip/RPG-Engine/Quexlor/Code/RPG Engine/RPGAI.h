//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

///
/// A subclass of RPGCharacter handling artificial intelligence.
/// RPGAI characters update primarily with mood selectors.
///

@interface RPGAI : RPGCharacter
	{
		SEL mood;
		float wakeDistanceSQ,playerDistanceSQ;
	}

	/// Continue walking toward current seek position
	-(void) walk;
	
	/// Set the AI's mood
	-(void) setMood:(SEL)newMood;

	/// Automatically choose a new mood
	-(void) chooseMood;

	/// Returns YES if the AI can wake up
	-(BOOL) canWakeup;

	// Returns a floating point value indicating the amount of time the AI will sleep for
	-(float) sleepTime;
	
@end
