//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "RPGEngine.h"

static BOOL anAmbienceIsPlaying = NO;

@interface RPGAmbience () // private methods
	-(void) stopAndUnload;
@end

@implementation RPGAmbience

	-(id) init
	{
		self = [super init];
		if( self != nil )
		{
			soundId = CD_MUTE;
			stopping = NO;
			maxDistanceSQ = 0.0f;
			timer = 0.0f;
		}
		return self;
	}
	
	-(void) dealloc
	{
		[self stopAndUnload];
		[super dealloc];
	}
	
	-(void) setGlobalIdFrom:(NSString*)mapFilename leafIndex:(int)leafIndex
	{
		// set global id to nil so this item is not saved
		globalId = nil;
	}
	
	-(void) onParentEstablished
	{
		[super onParentEstablished];

		if( [KITApp resourceExists:[self attributeForKey:kAttributeAmbienceFilename]] )
		{
			// does it have a radius?
			if( [self floatAttributeForKey:kAttributeAmbienceRadius] == 0.0f )
				[self setFloatAttributeForKey:kAttributeAmbienceRadius value:12.0f];
			
			// is it looping?
			id looping = [self attributeForKey:kAttributeAmbienceLooping];
			BOOL isYes = ([looping isKindOfClass:[NSString class]] && [looping isEqualToString:@"yes"]);
			BOOL loopingOn = (looping == nil || isYes || [looping intValue] == 1);
			[self setIntAttributeForKey:kAttributeAmbienceLooping value:loopingOn ? 1 : 0];

			// set maximum distance squared that the player can hear
			maxDistanceSQ = ([self floatAttributeForKey:kAttributeAmbienceRadius] * [[self getLevel] tileSize].width);
			maxDistanceSQ *= maxDistanceSQ;
		}
		else
			[self removeFromLevel];
	}

	-(void) onExit
	{
		[super onExit];
		
		[self stopAndUnload];
	}
	
	-(void) playWithVolume:(float)volume
	{
		NSString* filename = [self attributeForKey:kAttributeAmbienceFilename];
		if( !anAmbienceIsPlaying && !stopping )
		{
			// start loading sound
			[[KITSound sharedSound] loadSound:filename];
			
			// try to play sound, if it hasn't loaded yet, we will try again
			BOOL looping = [self intAttributeForKey:kAttributeAmbienceLooping];
			soundId = [[KITSound sharedSound] playSound:filename volume:volume
				pan:1.0f pitch:1.0f loop:looping group:kSoundGroupSingle];
			//KITLog(@"Started playing ambience %@ at volume %.1f", soundName, volume);
			
			if( soundId != CD_MUTE )
			{
				//KITLog(@"got ambience playing %@", soundName);
				anAmbienceIsPlaying = YES;
			}
		}
		else
			KITLog(@"Not playing ambience %@ because there is already another one playing", filename);
	}
	
	-(void) stopPlaying
	{
		stopping = YES;
	}
	
	-(void) update:(ccTime)delta
	{
		// use a timer to update so we don't bombard the engine
		if( timer <= 0.0f )
		{
			timer = 0.075f;
			
			if( stopping )
			{
				maxDistanceSQ *= 0.8f;
				maxDistanceSQ = clampf(maxDistanceSQ, 0.001f, 999999999.0f);
				//KITLog(@"stopping ambience %@ because asked to", soundName);
			}
		
			// get distance to player
			float distanceSQ = [[self getPlayer] distanceSQ:self.position];
			if( distanceSQ < maxDistanceSQ )
			{
				float volume = (1.0f - (distanceSQ / maxDistanceSQ)) * 0.6f;
				
				// start playing ambience now that player is close
				if( soundId == CD_MUTE )
					[self playWithVolume:volume];

				// change the volume of ambience while player is close
				else
					[[KITSound sharedSound] setVolume:soundId volume:volume];
			}
			else
			{
				[self stopAndUnload];
			}
		}
		else
		{
			timer -= delta;
		}
	}

	-(void) stopAndUnload
	{
		if( soundId != CD_MUTE )
		{
			// stop the ambience
			[[KITSound sharedSound] stopSound:soundId];
			soundId = CD_MUTE;
			anAmbienceIsPlaying = NO;

			// unload it to free up memory and prevent crashes
			[[KITSound sharedSound] unloadSound:[self attributeForKey:kAttributeAmbienceFilename]];
		}
	}
	
@end
