//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"


@implementation Skeleton
@end


@implementation BowSkeleton

	// this overrides the default chooseMood method in Enemy
	-(void) chooseMood
	{
		if( [self canWakeup] )
		{
			// ranged attack?
			if( ![self canAttack:[self getPlayer] ranged:NO]
			&& CCRANDOM_0_1() < 0.7f 
			&& [[self getLevel] countObjects:[ShotArrow class]] < 20 )
				[self setMood:kMoodRangedAttack];
			
			// seek
			else
				[self setMood:kMoodSeek];
		}
		else
			[self setMood:kMoodSleep];
	}

	-(void) moodRangedAttack
	{
		if( timer == kTimerUp )
		{
			// animate bow shot
			[self stopMoving];
			[self pointToward:[self getPlayer].position];
			[sprite runAction:[CCAnimate actionWithAnimation:[profile animationForKey:@"attack" index:currentDir]]];
			[self playSound:@"rangedAttack"];
			
			// create arrow (this is the ranged attack)
			CGPoint startPosition = ccp(self.position.x, self.position.y + 10.0f);
			ShotArrow* arrow = (ShotArrow*)[[self getLevel] createObject:[ShotArrow class] position:startPosition probability:1.0f flip:NO];
			
			// establish a vector toward player
			float angle = ccpToAngle(ccpSub([self getPlayer].position, self.position));
			angle += (CCRANDOM_MINUS1_1() * M_PI * 0.125f); // randomize
			arrow.vector = ccpForAngle(angle);
			arrow.speed = 300.0f;
			arrow.damage = 1.5f;
			arrow.delayTimer = 0.15f;
			arrow.lifeTimer = 5.0f; // long life means it will travel further and be more visible
			arrow.targetClass = [RPGPlayer class];			
			
			// wait to change mood
			timer = 1.0f + (CCRANDOM_0_1() * 0.5f);
		}
		else if( timer <= 0.0f )
			[self chooseMood];
	}

@end


@implementation Spider

	-(void) setProperties:(NSDictionary*)properties
	{
		[super setProperties:properties];
		
		// apply scale to life
		float newLife = [self floatAttributeForKey:kAttributeLife] * self.scale;
		[self setFloatAttributeForKey:kAttributeLife value:newLife];
		
		// get maximum scale
		maxScale = [[profile defaultAttributeForKey:kAttributeScale] floatValue];
	}

	-(void) update:(ccTime)newDelta
	{
		[super update:newDelta];

		if( [self isAlive] && self.scale < maxScale )
		{
			// grow larger over time
			self.scale += 0.01f * delta;
		
			// modify attributes randomly so as not to consume too much CPU
			if( CCRANDOM_0_1() < 0.5f )
			{
				// strength & life proportional to size
				[self setFloatAttributeForKey:kAttributeStrength value:(self.scale * 3.0f)];
				
				// speed faster when babies
				[self setFloatAttributeForKey:kAttributeDexterity value:(7.0f - (clampf(self.scale,0.0f,1.0f) * 6.0f))];
				
				// life increases with size, but not if injured to 30% of maxLife
				float currentLife = [self floatAttributeForKey:kAttributeLife];
				float currentMaxLife = [self floatAttributeForKey:kAttributeMaxLife];
				if( currentLife < currentMaxLife && currentLife > currentMaxLife * 0.3f )
					[self addFloatToAttributeForKey:kAttributeLife value:(self.scale * delta * 0.5f)];

				//KITLog(@"spider %@ life = %f scale = %f", self, life, self.scale);
			}
		}
	}

@end


@implementation SkeletonBoss

	-(void) createAmbience
	{
		[self createAmbience:@"tribal-beat.caf"];
	}

	-(void) chooseMood
	{
		if( [self canWakeup] )
		{
			// ranged attack?
			if( mood != kMoodRangedAttack
			&& playerDistanceSQ > 16000.0f // about 2 tiles
			&& CCRANDOM_0_1() < 0.1f 
			&& [[self getLevel] countObjects:[Skeleton class]] < 2 )
				[self setMood:kMoodRangedAttack];

			// seek
			else
				[self setMood:kMoodSeek];
		}
		else
		{
			[self setMood:kMoodSleep];
		}
	}
	
	-(void) moodRangedAttack
	{
		if( timer == kTimerUp )
		{
			// animate
			[self stopMoving];
			[self playSound:@"laugh"];
			
			// create skeleton
			[[self getLevel] createObject:[Skeleton class] position:[self attackPoint] probability:1.0f flip:YES];
			
			// wait a sec to change mood
			timer = 1.0f;
		}
		else if( timer <= 0.0f )
			[self chooseMood];
	}

	-(void) onDeath
	{
		// show player aura animation
		[(Player*)[self getPlayer] animateAura:3.0f];
		
		// leave player the bracer
		[[self getLevel] createObject:[Bracer class] position:self.position probability:1.0f flip:YES];

		// leave player some bones
		for(int i=0; i<9; i++)
			[[self getLevel] createObject:[Bone class] position:self.position probability:0.9f flip:YES];

		[super onDeath];
	}

@end


@implementation SpiderBoss

	-(void) createAmbience
	{
		[self createAmbience:@"tribal-beat.caf"];
	}

	-(void) setGlobalIdFrom:(NSString*)mapFilename leafIndex:(int)leafIndex
	{
		// no global id so we can always fight the end boss
		globalId = nil;
	}

	-(void) onDeath
	{
		// leave player meat
		for(int i=0; i<3; i++)
			[[self getLevel] createObject:[Meat class] position:self.position probability:1.0f flip:YES];
		for(int i=0; i<3; i++)
			[[self getLevel] createObject:[Bone class] position:self.position probability:0.9f flip:YES];

		// stoke the player
		[(Player*)[self getPlayer] animateAura:3.0f];

		// wait a bit then show end game
		[self runAction:[CCSequence actions:
			[CCDelayTime actionWithDuration:4.0f],
			[CCCallFunc actionWithTarget:[self getPlayer] selector:@selector(beatTheGame)],
			nil]];
		
		[super onDeath];
	}

@end

