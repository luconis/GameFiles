//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

@class Player;

@interface MenuLayerWithQuexlor : CCLayer
	{
		CCSprite* quexlor,*aura,*clock;
		Player* player;
	}

	-(void) addQuexlor:(KITProfile*)profile position:(CGPoint)pos;
	-(void) setPlayer:(Player*)p;
	-(Player*) getPlayer;
	-(void) redraw;
@end

@interface CharacterMenuLayer : MenuLayerWithQuexlor
	{
		ALuint menuAmbiance;
		CCSprite* swordIcon,*bracerIcon,*axeIcon,*ringIcon,*bookIcon;
		CCNode* lifeforceNode;
		CCMenuItemImage* strengthBtn,*dexterityBtn,*closeBtn,*homeBtn,*dpadBtn;
		CCSprite* strengthBtnGlow,*dexterityBtnGlow;
		CCLabelBMFont* bonesTxt,*strengthTxt,*dexterityTxt,*experienceTxt,*keysTxt,*redKeysTxt,*dpadTxt;
	}

	+(void) scene:(Player*)player;
	-(void) eraseLifeforce;
	-(void) drawLifeforce;
@end
