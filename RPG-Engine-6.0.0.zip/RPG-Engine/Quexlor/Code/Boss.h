//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

///
/// A subclass of RPGEnemy representing a boss enemy.
/// Specific Boss classes inherit from this class.
///
@interface Boss : RPGEnemy
	{
		RPGAmbience* ambience;
	}
	-(void) createAmbience;
	-(void) createAmbience:(NSString*)soundName;
@end

