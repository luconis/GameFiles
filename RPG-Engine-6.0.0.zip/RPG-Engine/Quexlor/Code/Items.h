//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

//
// items
//

@interface Experience : RPGItem
@end

@interface LifeForce : RPGItem
@end

@interface Key : RPGItem
@end

@interface Bone : RPGItem
@end

//
// items that give abilities
//

@interface Axes : RPGItem
@end

@interface Bracer : RPGItem
@end

//
// flames
//

@interface Flames : RPGItem
	{
		float lifeTimer;
	}
@end

//
// food subclass
//

@interface Food : RPGItem
@end

@interface Meat : Food
@end

@interface Fish : Food
@end

@interface Grapes : Food
@end

@interface Bread : Food
@end

@interface Grain : Food
@end

@interface Flour : Food
@end

@interface Mushroom : Food
@end

@interface BadMushroom : Food
@end

//
// item's that can be opened or destroyed by attacking
//

@interface Chest : RPGLevelObject
@end

@interface WeakRock : RPGLevelObject
@end

@interface RunePillar : RPGLevelObject
@end

@interface Switch : RPGItem
@end

@interface Door : RPGItem
@end


@interface Teleport : RPGItem
	{
		BOOL justTeleported;
	}
@end

//
// misc
//

@interface Warp : RPGWarp
@end

@interface Ambience : RPGAmbience
@end
