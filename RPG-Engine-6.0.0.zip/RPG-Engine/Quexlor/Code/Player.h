//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

///
/// A subclass of RPGPlayer that acts out the role of a barbarian king
///
@interface Player : RPGPlayer

	/// Increase times beaten the game and show the victory menu
	-(void) beatTheGame;
	
	/// Returns an integer count of the number of life force containers obtained
	-(int) countLifeforce;
	
	/// Returns an integer count of the number of secrets obtained
	-(int) countSecrets;
	
	/// Run the clock-like animation
	-(void) animateClock;
	
	/// Run the aura animation with the given scale
	-(void) animateAura:(float)scale;
	
	/// Run a big double aura animation with the given scale
	-(void) animateAuras:(float)scale;
	
@end
