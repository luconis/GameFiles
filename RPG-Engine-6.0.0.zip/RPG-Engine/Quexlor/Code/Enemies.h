//
//  See the file 'LICENSE_iPhoneGameKit.txt' for the license governing this code.
//      The license can also be obtained online at:
//          http://www.iPhoneGameKit.com/license
//

#import "Quexlor.h"

@interface Skeleton : RPGEnemy
@end

@interface BowSkeleton : RPGEnemy
@end

@interface Spider : RPGEnemy
	{
		float maxScale;
	}
@end

@interface SpiderBoss : Boss
@end

@interface SkeletonBoss : Boss
@end
